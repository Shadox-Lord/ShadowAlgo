import React from "react";

/**
 * Metadata Pill (Outline)
 */
export const MetaPill = ({ children, icon: Icon }) => (
  <span className="bg-white border border-[#E5E7EB] rounded-full px-3 py-1 text-xs font-medium text-[#6B7280] inline-flex items-center gap-1.5 h-7">
    {Icon && <Icon size={14} />}
    {children}
  </span>
);

/**
 * Soft Action Pill (Secondary)
 */
export const ActionPill = ({ children, icon: Icon, onClick }) => (
  <button
    onClick={onClick}
    className="bg-[#EFF6FF] text-[#2563EB] rounded-full px-3 py-1.5 text-sm font-medium inline-flex items-center gap-1.5 h-8 hover:bg-[#DBEAFE] transition-colors"
  >
    {Icon && <Icon size={16} />}
    {children}
  </button>
);

/**
 * Status Pill
 */
export const StatusPill = ({ status, label }) => {
  const isHealthy =
    status === "ACTIVE" || status === "SUCCESS" || status === "pending";
  const isWarning = status === "BLOCKED" || status === "REJECTED";

  return (
    <span className="bg-white border border-[#E5E7EB] rounded-full px-3 py-1 text-xs font-medium text-[#6B7280] inline-flex items-center gap-1.5 h-7">
      <span
        className={`w-1.5 h-1.5 rounded-full ${isHealthy ? "bg-[#10B981]" : isWarning ? "bg-[#F59E0B]" : "bg-[#EF4444]"}`}
      />
      {label || status}
    </span>
  );
};

/**
 * Circular Progress Ring
 */
export const CircularRing = ({ value, label, color = "#EA580C" }) => {
  const radius = 18;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (value / 100) * circumference;

  return (
    <div className="flex flex-col items-center gap-2">
      <div className="relative w-12 h-12">
        <svg className="w-full h-full -rotate-90">
          <circle
            cx="24"
            cy="24"
            r={radius}
            stroke="#F3F4F6"
            strokeWidth="3"
            fill="transparent"
          />
          <circle
            cx="24"
            cy="24"
            r={radius}
            stroke={color}
            strokeWidth="3"
            fill="transparent"
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            strokeLinecap="round"
          />
        </svg>
        <span className="absolute inset-0 flex items-center justify-center text-[10px] font-semibold text-[#111827]">
          {value}%
        </span>
      </div>
      <span className="text-[10px] font-medium text-[#6B7280] uppercase tracking-wider">
        {label}
      </span>
    </div>
  );
};

/**
 * SaaS Card
 */
export const Card = ({ title, subtitle, children, footer, className = "" }) => (
  <div
    className={`bg-white rounded-xl border border-[#E5E7EB] p-6 flex flex-col gap-4 ${className}`}
  >
    {(title || subtitle) && (
      <div className="flex flex-col gap-1">
        {title && (
          <h3 className="text-base font-semibold text-[#111827]">{title}</h3>
        )}
        {subtitle && <p className="text-sm text-[#6B7280]">{subtitle}</p>}
      </div>
    )}
    <div className="flex-1">{children}</div>
    {footer && <div className="pt-4 border-t border-[#E5E7EB]">{footer}</div>}
  </div>
);
