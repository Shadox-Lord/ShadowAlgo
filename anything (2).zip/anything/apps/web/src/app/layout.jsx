import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import React from "react";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 5, // 5 minutes
      cacheTime: 1000 * 60 * 30, // 30 minutes
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
});

export default function RootLayout({ children }) {
  return (
    <QueryClientProvider client={queryClient}>
      <html lang="en">
        <body className="bg-[#FFFFFF] text-[#111827] font-sans antialiased min-h-screen font-inter">
          <div className="max-w-[1400px] mx-auto px-6 py-8">{children}</div>
        </body>
      </html>
    </QueryClientProvider>
  );
}
