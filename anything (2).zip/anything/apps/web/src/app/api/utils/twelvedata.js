/**
 * TwelveData API Wrapper
 * Fetches real OHLCV candles for EURUSD / XAUUSD
 * Set TWELVE_DATA_API_KEY in env vars
 * Free plan: 800 credits/day, 8 requests/min
 */

const BASE_URL = "https://api.twelvedata.com";

// Map our internal symbols to TwelveData format
const SYMBOL_MAP = {
  EURUSD: "EUR/USD",
  XAUUSD: "XAU/USD",
};

// Map our timeframe labels to TwelveData intervals
const TF_MAP = {
  H1: "1h",
  H4: "4h",
  D1: "1day",
  "15m": "15min",
  "5m": "5min",
};

/**
 * Fetch OHLCV candles from TwelveData
 * @param {string} symbol  - e.g. 'EURUSD'
 * @param {string} tf      - e.g. 'H4'
 * @param {number} count   - number of candles (max 5000 on paid, 800 free)
 * @returns {{ candles: Array, currentPrice: number, source: string }}
 */
export async function fetchOHLCV(symbol, tf = "H4", count = 120) {
  const apiKey = process.env.TWELVE_DATA_API_KEY;
  if (!apiKey) {
    console.warn("[TwelveData] No API key set — using synthetic fallback");
    return generateSyntheticOHLCV(symbol, count);
  }

  const tdSymbol = SYMBOL_MAP[symbol] || symbol;
  const tdInterval = TF_MAP[tf] || "4h";

  try {
    const url = `${BASE_URL}/time_series?symbol=${encodeURIComponent(tdSymbol)}&interval=${tdInterval}&outputsize=${count}&apikey=${apiKey}&format=JSON`;
    const res = await fetch(url, { next: { revalidate: 60 } });

    if (!res.ok) throw new Error(`TwelveData HTTP ${res.status}`);
    const json = await res.json();

    if (json.status === "error") {
      throw new Error(`TwelveData error: ${json.message}`);
    }

    const raw = json.values;
    if (!raw || !Array.isArray(raw) || raw.length === 0) {
      throw new Error("TwelveData returned empty values");
    }

    // TwelveData returns newest-first; reverse for chronological order
    const candles = raw.reverse().map((c) => ({
      ts: c.datetime,
      open: parseFloat(c.open),
      high: parseFloat(c.high),
      low: parseFloat(c.low),
      close: parseFloat(c.close),
      volume: parseFloat(c.volume || 0),
    }));

    const currentPrice = candles[candles.length - 1].close;
    console.log(
      `[TwelveData] ✅ ${symbol} ${tf} — ${candles.length} candles, last close: ${currentPrice}`,
    );

    return { candles, currentPrice, source: "twelvedata" };
  } catch (err) {
    console.error(
      `[TwelveData] Fetch failed for ${symbol}: ${err.message} — falling back to synthetic`,
    );
    return generateSyntheticOHLCV(symbol, count);
  }
}

/**
 * Fetch the latest price only (lightweight, 1 credit)
 */
export async function fetchLatestPrice(symbol) {
  const apiKey = process.env.TWELVE_DATA_API_KEY;
  if (!apiKey) return null;

  const tdSymbol = SYMBOL_MAP[symbol] || symbol;
  try {
    const url = `${BASE_URL}/price?symbol=${encodeURIComponent(tdSymbol)}&apikey=${apiKey}`;
    const res = await fetch(url);
    if (!res.ok) return null;
    const json = await res.json();
    return json.price ? parseFloat(json.price) : null;
  } catch {
    return null;
  }
}

/**
 * Deterministic synthetic OHLCV fallback (used when no API key)
 * Slightly more realistic than pure random walk — uses geometric Brownian motion
 */
export function generateSyntheticOHLCV(symbol, count = 120) {
  const basePrice = symbol === "XAUUSD" ? 2320.0 : 1.0845;
  const volatility = symbol === "XAUUSD" ? 6.0 : 0.0006;
  const drift = 0.00002; // slight upward drift

  const candles = [];
  let price = basePrice;
  const now = Date.now();

  for (let i = count; i >= 0; i--) {
    const shock = (Math.random() - 0.5) * 2 * volatility;
    const move = price * (drift + shock);
    const open = price;
    const close = Math.max(0.0001, price + move);
    const high = Math.max(open, close) + Math.random() * volatility * 0.6;
    const low = Math.min(open, close) - Math.random() * volatility * 0.6;
    const ts = new Date(now - i * 4 * 60 * 60 * 1000).toISOString();
    candles.push({
      ts,
      open,
      high,
      low,
      close: Math.max(0.0001, close),
      volume: 500 + Math.random() * 3000,
    });
    price = close;
  }

  return { candles, currentPrice: price, source: "synthetic" };
}
