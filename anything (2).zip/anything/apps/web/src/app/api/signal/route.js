import sql from "@/app/api/utils/sql";
import {
  runKronosForecaster,
  runShadowAuditor,
  dispatchTelegramSignal,
  checkKillSwitches,
  checkNewsBlackout,
  SUPPORTED_ASSETS,
  CONFIG,
} from "@/app/api/utils/trading-logic";
import { fetchOHLCV } from "@/app/api/utils/twelvedata";

// Inline Pearson ρ for correlation gate (avoids self-HTTP call)
function pearsonR(x, y) {
  const n = Math.min(x.length, y.length);
  if (n < 4) return 0;
  const xa = x.slice(-n),
    ya = y.slice(-n);
  const mx = xa.reduce((s, v) => s + v, 0) / n;
  const my = ya.reduce((s, v) => s + v, 0) / n;
  let num = 0,
    dx2 = 0,
    dy2 = 0;
  for (let i = 0; i < n; i++) {
    const ex = xa[i] - mx,
      ey = ya[i] - my;
    num += ex * ey;
    dx2 += ex * ex;
    dy2 += ey * ey;
  }
  const denom = Math.sqrt(dx2 * dy2);
  return denom === 0 ? 0 : num / denom;
}

export async function POST(request) {
  try {
    const body = await request.json();
    const { instrument: rawInstrument, timeframe: rawTimeframe } = body;

    const instrument = (rawInstrument || "EURUSD")
      .toUpperCase()
      .replace("/", "");
    const timeframe = rawTimeframe || "H4";

    if (!SUPPORTED_ASSETS.includes(instrument)) {
      return Response.json(
        {
          error: `Unsupported instrument. Use: ${SUPPORTED_ASSETS.join(", ")}`,
        },
        { status: 400 },
      );
    }

    // ── 0a. System state — pause check ──
    const [systemState] = await sql`SELECT * FROM system_state WHERE id = 1`;
    if (systemState?.is_paused) {
      return Response.json(
        { error: "System is paused. Use /resume to re-activate." },
        { status: 403 },
      );
    }

    // ── 0b. News blackout gate ──
    const newsCheck = checkNewsBlackout();
    if (newsCheck.blocked) {
      return Response.json({ error: newsCheck.reason }, { status: 403 });
    }

    // ── 0c. Daily drawdown kill-switch ──
    const currentEquity = systemState?.current_equity || 100000;
    const dailyStartEquity = systemState?.daily_start_equity || 100000;
    const dailyDD =
      ((dailyStartEquity - currentEquity) / dailyStartEquity) * 100;
    if (dailyDD >= CONFIG.MAX_DAILY_LOSS_PERCENT) {
      return Response.json(
        {
          error: `Daily drawdown limit hit (${dailyDD.toFixed(2)}%). Trading halted.`,
        },
        { status: 403 },
      );
    }

    // ── 0d. Consecutive loss kill-switch (Patch 4) ──
    const killSwitch = await checkKillSwitches();
    if (killSwitch.blocked) {
      return Response.json(
        {
          error: `Kill-switch triggered: ${killSwitch.reason}. Reset required.`,
        },
        { status: 403 },
      );
    }

    // ── 0e. Correlation gate — block if ρ > 0.7 with an active correlated trade ──
    const activeOther = await sql`
      SELECT instrument FROM audit_logs
      WHERE outcome = 'pending' AND signal_status = 'ACTIVE'
        AND instrument != ${instrument}
      LIMIT 1
    `;
    if (activeOther.length > 0) {
      try {
        const [eu, xau] = await Promise.all([
          fetchOHLCV("EURUSD", timeframe, 30),
          fetchOHLCV("XAUUSD", timeframe, 30),
        ]);
        const euRet = eu.candles
          .slice(1)
          .map((c, i) => Math.log(c.close / eu.candles[i].close));
        const xauRet = xau.candles
          .slice(1)
          .map((c, i) => Math.log(c.close / xau.candles[i].close));
        const rho = pearsonR(euRet.slice(-20), xauRet.slice(-20));
        if (Math.abs(rho) >= 0.7) {
          return Response.json(
            {
              error: `Correlation gate blocked: ρ=${rho.toFixed(3)} ≥ 0.7 with active ${activeOther[0].instrument}`,
            },
            { status: 403 },
          );
        }
      } catch (corrErr) {
        console.warn("[Signal] Correlation check skipped:", corrErr.message);
      }
    }

    // ── 1. Fetch REAL OHLCV from TwelveData (falls back to synthetic if no key) ──
    const { candles, currentPrice, source } = await fetchOHLCV(
      instrument,
      timeframe,
      120,
    );
    const ohlcv = { instrument, close: currentPrice };

    // ── 2. LAYER 1: KRONOS FORECASTER ──
    const l1Result = await runKronosForecaster(ohlcv, timeframe, candles);

    // ── 3. LAYER 2: SHADOW AUDITOR ──
    const l2Result = await runShadowAuditor(
      l1Result,
      ohlcv,
      candles,
      currentEquity,
    );

    // ── 4. Telegram dispatch ──
    let telegramMessageId = null;
    if (l2Result.signal_status !== "FALLBACK_FAILED") {
      telegramMessageId = await dispatchTelegramSignal(l2Result);
    }

    // ── 5. Append-only audit log ──
    const [log] = await sql`
      INSERT INTO audit_logs (
        instrument, timeframe, direction, entry_price, stop_loss,
        take_profit_1, take_profit_2, lot_size, risk_percent,
        adx_value, atr_value, uncertainty_score, signal_status,
        block_reason, prompt_hash, model_checkpoint, time_kill_utc,
        telegram_message_id, smc_context, breakeven_level, atr_pips
      ) VALUES (
        ${l2Result.instrument},
        ${timeframe},
        ${l2Result.direction || null},
        ${l2Result.entry_price || null},
        ${l2Result.stop_loss || null},
        ${l2Result.take_profit_1 || null},
        ${l2Result.take_profit_2 || null},
        ${l2Result.lot_size || null},
        ${l2Result.risk_percent || CONFIG.MAX_TRADE_RISK_PERCENT},
        ${l2Result.adx_value},
        ${l2Result.atr_value},
        ${l2Result.uncertainty_score},
        ${l2Result.signal_status},
        ${l2Result.block_reason},
        ${l2Result.prompt_hash || null},
        ${l2Result.model_checkpoint || null},
        ${l2Result.time_kill_utc || null},
        ${telegramMessageId || null},
        ${l2Result.smc_context || null},
        ${l2Result.breakeven_level || null},
        ${l2Result.atr_pips || null}
      ) RETURNING *
    `;

    return Response.json({
      layer2: l2Result,
      log_id: log.id,
      telegram_message_id: telegramMessageId,
      data_source: source,
    });
  } catch (error) {
    console.error("[Signal] Generation failed:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}
