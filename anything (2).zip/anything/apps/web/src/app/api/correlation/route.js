import { fetchOHLCV } from "@/app/api/utils/twelvedata";

/**
 * Dynamic Correlation Monitor
 * Computes rolling Pearson ρ between EURUSD and XAUUSD returns
 * Block threshold: ρ > 0.7 over last 20 candles
 */

const BLOCK_THRESHOLD = 0.7;
const ROLLING_PERIOD = 20;

/**
 * Pearson correlation coefficient between two numeric arrays
 */
function pearsonCorrelation(x, y) {
  const n = Math.min(x.length, y.length);
  if (n < 4) return 0;
  const xa = x.slice(-n),
    ya = y.slice(-n);
  const mx = xa.reduce((s, v) => s + v, 0) / n;
  const my = ya.reduce((s, v) => s + v, 0) / n;
  let num = 0,
    dx2 = 0,
    dy2 = 0;
  for (let i = 0; i < n; i++) {
    const ex = xa[i] - mx,
      ey = ya[i] - my;
    num += ex * ey;
    dx2 += ex * ex;
    dy2 += ey * ey;
  }
  const denom = Math.sqrt(dx2 * dy2);
  return denom === 0 ? 0 : num / denom;
}

/**
 * Compute log-returns from close prices
 */
function logReturns(candles) {
  const returns = [];
  for (let i = 1; i < candles.length; i++) {
    returns.push(Math.log(candles[i].close / candles[i - 1].close));
  }
  return returns;
}

/**
 * Compute rolling correlation over windows of `period`
 */
function rollingCorrelation(r1, r2, period) {
  const n = Math.min(r1.length, r2.length);
  const result = [];
  for (let i = period; i <= n; i++) {
    const rho = pearsonCorrelation(
      r1.slice(i - period, i),
      r2.slice(i - period, i),
    );
    result.push(parseFloat(rho.toFixed(4)));
  }
  return result;
}

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const tf = searchParams.get("tf") || "H4";
    const candles = parseInt(searchParams.get("candles") || "60");

    // Fetch both pairs in parallel
    const [eu, xau] = await Promise.all([
      fetchOHLCV("EURUSD", tf, candles),
      fetchOHLCV("XAUUSD", tf, candles),
    ]);

    // Align candle arrays to same length
    const len = Math.min(eu.candles.length, xau.candles.length);
    const euRet = logReturns(eu.candles.slice(-len));
    const xauRet = logReturns(xau.candles.slice(-len));

    // Spot (last 20c) and full correlation
    const spotRho = pearsonCorrelation(
      euRet.slice(-ROLLING_PERIOD),
      xauRet.slice(-ROLLING_PERIOD),
    );
    const fullRho = pearsonCorrelation(euRet, xauRet);
    const rolling = rollingCorrelation(euRet, xauRet, ROLLING_PERIOD);

    // Build chart data (index-aligned rolling ρ)
    const chartData = rolling.map((rho, i) => ({
      candle: i + ROLLING_PERIOD,
      rho,
    }));

    const isBlocked = Math.abs(spotRho) >= BLOCK_THRESHOLD;
    const correlation = parseFloat(spotRho.toFixed(4));
    const direction = correlation > 0 ? "positive" : "negative";

    return Response.json({
      tf,
      candlesUsed: len,
      source: eu.source,
      eurusd: { lastClose: eu.currentPrice },
      xauusd: { lastClose: xau.currentPrice },
      correlation: {
        spot20c: correlation,
        full: parseFloat(fullRho.toFixed(4)),
        direction,
        blocked: isBlocked,
        threshold: BLOCK_THRESHOLD,
        verdict: isBlocked
          ? `⛔ CORRELATION BLOCKED (ρ=${correlation} ≥ ${BLOCK_THRESHOLD}) — Do not run both pairs simultaneously`
          : `✅ Correlation OK (ρ=${correlation} < ${BLOCK_THRESHOLD}) — Pairs can trade independently`,
      },
      chartData,
    });
  } catch (err) {
    console.error("[Correlation]", err);
    return Response.json({ error: err.message }, { status: 500 });
  }
}
