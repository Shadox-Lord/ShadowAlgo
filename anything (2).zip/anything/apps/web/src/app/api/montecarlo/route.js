import sql from "@/app/api/utils/sql";

/**
 * Monte Carlo Ruin Simulation
 * Runs N simulations of randomised trade sequences from audit log history
 * Returns: probability of ruin, median equity curve, percentile bands
 */

const DEFAULT_SIMULATIONS = 5000;
const DEFAULT_FUTURE_TRADES = 100;
const RUIN_THRESHOLD = 0.1; // account considered "ruined" at -90% drawdown

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const simCount = Math.min(
      10000,
      parseInt(searchParams.get("sims") || DEFAULT_SIMULATIONS),
    );
    const tradesToSim = Math.min(
      500,
      parseInt(searchParams.get("trades") || DEFAULT_FUTURE_TRADES),
    );
    const startEquity = parseFloat(searchParams.get("equity") || 100000);

    // Pull closed trades from audit log
    const closed = await sql`
      SELECT outcome_pnl_pips, lot_size, outcome
      FROM audit_logs
      WHERE outcome IN ('tp1_hit','tp2_hit','sl_hit','kill_switch')
      ORDER BY outcome_timestamp_utc DESC
    `;

    // Build R-multiple distribution from closed trades
    // Each pip result is normalised into R-multiples (risk units)
    // If no real data: use Phase 1 backtest estimates (52.94% WR, 5.46R avg)
    let rMultiples;
    if (closed.length >= 5) {
      rMultiples = closed.map((t) => {
        const pips = t.outcome_pnl_pips || 0;
        // Rough pip-to-R conversion: assume 60 pip risk = 1R
        return pips / 60;
      });
    } else {
      // Seed with backtest distribution (post-rehabilitation)
      // Win rate 52.94% | Avg win 5.46R | Avg loss -1.0R
      rMultiples = Array.from({ length: 17 }, (_, i) => (i < 9 ? 5.46 : -1.0));
    }

    const winRate = rMultiples.filter((r) => r > 0).length / rMultiples.length;
    const avgWin =
      rMultiples.filter((r) => r > 0).reduce((s, r) => s + r, 0) /
      Math.max(1, rMultiples.filter((r) => r > 0).length);
    const avgLoss =
      rMultiples.filter((r) => r < 0).reduce((s, r) => s + r, 0) /
      Math.max(1, rMultiples.filter((r) => r < 0).length);
    const expectancy = winRate * avgWin + (1 - winRate) * avgLoss;

    // Risk per trade = 0.3% equity
    const riskPerTrade = 0.003;

    // ── Monte Carlo simulation ──
    let ruinCount = 0;
    const finalEquities = [];
    const samplePaths = []; // store 20 random paths for chart
    const captureEvery = Math.floor(simCount / 20);

    for (let sim = 0; sim < simCount; sim++) {
      let equity = startEquity;
      let peakEquity = startEquity;
      let ruined = false;
      const path = sim % captureEvery === 0 ? [equity] : null;

      for (let trade = 0; trade < tradesToSim; trade++) {
        // Sample a random R-multiple from historical distribution
        const rSample =
          rMultiples[Math.floor(Math.random() * rMultiples.length)];
        const pnl = equity * riskPerTrade * rSample;
        equity = Math.max(0, equity + pnl);
        peakEquity = Math.max(peakEquity, equity);

        const drawdown = (peakEquity - equity) / peakEquity;
        if (drawdown >= 1 - RUIN_THRESHOLD) {
          ruined = true;
          if (path) path.push(equity);
          break;
        }
        if (path) path.push(equity);
      }

      if (ruined) ruinCount++;
      finalEquities.push(equity);
      if (path && path.length > 1) samplePaths.push(path);
    }

    // Sort final equities for percentile extraction
    finalEquities.sort((a, b) => a - b);
    const pct = (p) => finalEquities[Math.floor(p * finalEquities.length)];

    const probabilityOfRuin = ruinCount / simCount;

    // Build percentile equity bands for chart (normalised to trade index)
    const chartPoints = [];
    for (let t = 0; t <= Math.min(tradesToSim, 50); t++) {
      const idx = Math.floor(t * (tradesToSim / 50));
      const vals = samplePaths
        .map((p) => p[Math.min(idx, p.length - 1)] || 0)
        .sort((a, b) => a - b);
      if (vals.length === 0) continue;
      const q = (x) => vals[Math.floor(x * vals.length)] || 0;
      chartPoints.push({
        trade: t * Math.floor(tradesToSim / 50),
        p10: q(0.1),
        p25: q(0.25),
        p50: q(0.5),
        p75: q(0.75),
        p90: q(0.9),
      });
    }

    return Response.json({
      inputs: {
        simulations: simCount,
        futureTrades: tradesToSim,
        startEquity,
        historicalTrades: closed.length,
        dataSource: closed.length >= 5 ? "live_audit_log" : "backtest_seed",
      },
      distribution: {
        winRate: parseFloat((winRate * 100).toFixed(2)),
        avgWinR: parseFloat(avgWin.toFixed(3)),
        avgLossR: parseFloat(Math.abs(avgLoss).toFixed(3)),
        expectancyR: parseFloat(expectancy.toFixed(3)),
        rMultiples: rMultiples.slice(0, 50), // cap for response size
      },
      results: {
        probabilityOfRuin: parseFloat((probabilityOfRuin * 100).toFixed(2)),
        ruinedSimulations: ruinCount,
        medianFinalEquity: parseFloat(pct(0.5).toFixed(2)),
        p10FinalEquity: parseFloat(pct(0.1).toFixed(2)),
        p90FinalEquity: parseFloat(pct(0.9).toFixed(2)),
        expectedReturn: parseFloat(
          (((pct(0.5) - startEquity) / startEquity) * 100).toFixed(2),
        ),
      },
      verdict:
        probabilityOfRuin < 0.05
          ? "SAFE"
          : probabilityOfRuin < 0.15
            ? "CAUTION"
            : "DANGER",
      chartData: chartPoints,
    });
  } catch (err) {
    console.error("[MonteCarlo]", err);
    return Response.json({ error: err.message }, { status: 500 });
  }
}
