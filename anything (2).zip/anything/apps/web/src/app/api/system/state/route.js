import sql from "@/app/api/utils/sql";

export async function GET() {
  try {
    const [state] = await sql`SELECT * FROM system_state WHERE id = 1`;
    return Response.json(state);
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}

export async function PATCH(request) {
  try {
    const body = await request.json();
    const allowedKeys = [
      "is_paused",
      "current_equity",
      "daily_start_equity",
      "max_equity",
    ];

    // Build dynamic update
    const updates = [];
    const values = [];
    let i = 1;

    for (const key of allowedKeys) {
      if (body[key] !== undefined) {
        updates.push(`${key} = $${i}`);
        values.push(body[key]);
        i++;
      }
    }

    if (updates.length === 0)
      return Response.json({ error: "No fields to update" }, { status: 400 });

    const query = `UPDATE system_state SET ${updates.join(", ")} WHERE id = 1 RETURNING *`;
    const [updated] = await sql(query, values);

    return Response.json(updated);
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}
