import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const limit = parseInt(searchParams.get("limit") || "50");

    const logs = await sql`
      SELECT * FROM audit_logs 
      ORDER BY created_at DESC 
      LIMIT ${limit}
    `;

    return Response.json(logs);
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}

/**
 * Update an audit log (e.g. marking outcome)
 */
export async function PATCH(request) {
  try {
    const { id, outcome, outcome_pnl_pips } = await request.json();

    const [updated] = await sql`
      UPDATE audit_logs 
      SET 
        outcome = ${outcome},
        outcome_pnl_pips = ${outcome_pnl_pips},
        outcome_timestamp_utc = CURRENT_TIMESTAMP
      WHERE id = ${id}
      RETURNING *
    `;

    return Response.json(updated);
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}
