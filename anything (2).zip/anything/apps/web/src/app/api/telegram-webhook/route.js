import sql from "@/app/api/utils/sql";
import { escapeMarkdownV2 } from "@/app/api/utils/trading-logic";

export async function POST(request) {
  try {
    const body = await request.json();
    const { message } = body;

    if (!message || !message.text) {
      return Response.json({ ok: true });
    }

    const text = message.text.toLowerCase();
    const chatId = message.chat.id;
    const token = process.env.TELEGRAM_BOT_TOKEN;

    const sendResponse = async (responseText) => {
      await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          chat_id: chatId,
          text: responseText,
          parse_mode: "MarkdownV2",
        }),
      });
    };

    if (text.startsWith("/signal")) {
      const parts = text.split(" ");
      // Normalise: strip "/" and uppercase → EURUSD, XAUUSD, etc.
      const rawInst = parts[1]
        ? parts[1].toUpperCase().replace("/", "")
        : "EURUSD";
      const timeframe = parts[2] ? parts[2].toUpperCase() : "H4";

      const baseUrl = process.env.NEXT_PUBLIC_CREATE_APP_URL || "";
      const signalResponse = await fetch(`${baseUrl}/api/signal`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ instrument: rawInst, timeframe }),
      });

      if (!signalResponse.ok) {
        const err = await signalResponse.json().catch(() => ({}));
        await sendResponse(
          escapeMarkdownV2(
            `❌ ${err.error || "Signal generation failed or system is paused."}`,
          ),
        );
      }
      // Signal logic dispatches the result to Telegram itself
    } else if (text === "/status") {
      const [state] = await sql`SELECT * FROM system_state WHERE id = 1`;
      const activeTrades =
        await sql`SELECT * FROM audit_logs WHERE outcome = 'pending' AND signal_status = 'ACTIVE'`;
      const pnl = state.current_equity - state.daily_start_equity;
      const dailyDD = (
        ((state.daily_start_equity - state.current_equity) /
          state.daily_start_equity) *
        100
      ).toFixed(2);

      const statusMsg = `📊 *SYSTEM STATUS — KRONOS \\+ SHADOW v3\\.0*
⚖️ Equity: \\$${escapeMarkdownV2(state.current_equity.toLocaleString())}
📈 Daily P&L: \\$${escapeMarkdownV2(pnl.toLocaleString())}
📉 Daily DD: ${escapeMarkdownV2(dailyDD)}\\%
⏸ Paused: ${state.is_paused ? "Yes" : "No"}
📦 Active Trades: ${activeTrades.length}
🔍 Assets: EURUSD, XAUUSD \\| TF: H4, H1
${activeTrades.map((t) => `• ${escapeMarkdownV2(t.instrument)} \\| ${escapeMarkdownV2(t.direction || "?")} \\| Entry: ${escapeMarkdownV2(String(t.entry_price || "?"))}`).join("\n") || "_None_"}`;

      await sendResponse(statusMsg);
    } else if (text === "/pause") {
      await sql`UPDATE system_state SET is_paused = TRUE WHERE id = 1`;
      await sendResponse(
        escapeMarkdownV2("⏸ System paused. No new signals will be generated."),
      );
    } else if (text === "/resume") {
      await sql`UPDATE system_state SET is_paused = FALSE WHERE id = 1`;
      await sendResponse(escapeMarkdownV2("▶️ System resumed."));
    } else if (text === "/risk") {
      const [state] = await sql`SELECT * FROM system_state WHERE id = 1`;
      const dailyDD = (
        ((state.daily_start_equity - state.current_equity) /
          state.daily_start_equity) *
        100
      ).toFixed(2);
      const maxDD = (
        ((state.max_equity - state.current_equity) / state.max_equity) *
        100
      ).toFixed(2);

      const riskMsg = `⚖️ *RISK METRICS*
📉 Daily DD: ${dailyDD}%
📉 Max DD: ${maxDD}%
🛡 Daily Start: $${state.daily_start_equity.toLocaleString()}
🚀 All-time High: $${state.max_equity.toLocaleString()}`;

      await sendResponse(escapeMarkdownV2(riskMsg));
    } else if (text.startsWith("/history")) {
      const limit = parseInt(text.split(" ")[1]) || 5;
      const history = await sql`
        SELECT instrument, direction, outcome_pnl_pips, outcome 
        FROM audit_logs 
        WHERE signal_status = 'ACTIVE' AND outcome != 'pending'
        ORDER BY created_at DESC 
        LIMIT ${limit}
      `;

      const historyMsg = `📜 *TRADE HISTORY (Last ${limit})*
${history.map((h) => `• ${escapeMarkdownV2(h.instrument)} | ${h.direction} | ${h.outcome_pnl_pips > 0 ? "+" : ""}${h.outcome_pnl_pips}p | ${h.outcome}`).join("\n") || "No closed trades"}`;

      await sendResponse(escapeMarkdownV2(historyMsg));
    }

    return Response.json({ ok: true });
  } catch (error) {
    console.error("Telegram webhook error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}
