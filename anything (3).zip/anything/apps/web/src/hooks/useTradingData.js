import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

export function useTradingData({ wfaWindows = 4 } = {}) {
  const queryClient = useQueryClient();

  const { data: logs = [], isLoading: logsLoading } = useQuery({
    queryKey: ["audit-logs"],
    queryFn: () => fetch("/api/audit-logs").then((r) => r.json()),
    refetchInterval: 10000,
  });

  const { data: systemState } = useQuery({
    queryKey: ["system-state"],
    queryFn: () => fetch("/api/system/state").then((r) => r.json()),
    refetchInterval: 15000,
  });

  const {
    data: monteCarlo,
    isFetching: mcFetching,
    refetch: refetchMC,
  } = useQuery({
    queryKey: ["montecarlo"],
    queryFn: () =>
      fetch("/api/montecarlo?sims=5000&trades=100").then((r) => r.json()),
    enabled: false,
    staleTime: 60000,
  });

  const {
    data: correlation,
    isFetching: corrFetching,
    refetch: refetchCorr,
  } = useQuery({
    queryKey: ["correlation"],
    queryFn: () =>
      fetch("/api/correlation?tf=H4&candles=60").then((r) => r.json()),
    refetchInterval: 60000,
  });

  const {
    data: wfa,
    isFetching: wfaFetching,
    refetch: refetchWFA,
  } = useQuery({
    queryKey: ["wfa", wfaWindows],
    queryFn: () =>
      fetch(`/api/wfa?windows=${wfaWindows}&minTrades=5`).then((r) => r.json()),
    enabled: false,
    staleTime: 120000,
  });

  const { data: newsCalendar, refetch: refetchNews } = useQuery({
    queryKey: ["news-calendar"],
    queryFn: () =>
      fetch("/api/news-calendar?hours=48&impact=high").then((r) => r.json()),
    refetchInterval: 5 * 60 * 1000,
    staleTime: 60000,
  });

  const togglePause = useMutation({
    mutationFn: (isPaused) =>
      fetch("/api/system/state", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ is_paused: isPaused }),
      }).then((r) => r.json()),
    onSuccess: () =>
      queryClient.invalidateQueries({ queryKey: ["system-state"] }),
  });

  const triggerSignal = useMutation({
    mutationFn: (params) =>
      fetch("/api/signal", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(params),
      }).then((r) => r.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["audit-logs"] });
    },
  });

  const closeTrade = useMutation({
    mutationFn: ({ id, outcome, pips }) =>
      fetch("/api/audit-logs", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, outcome, outcome_pnl_pips: pips }),
      }).then((r) => r.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["audit-logs"] });
      queryClient.invalidateQueries({ queryKey: ["system-state"] });
    },
  });

  return {
    logs,
    logsLoading,
    systemState,
    monteCarlo,
    mcFetching,
    refetchMC,
    correlation,
    corrFetching,
    refetchCorr,
    wfa,
    wfaFetching,
    refetchWFA,
    newsCalendar,
    refetchNews,
    togglePause,
    triggerSignal,
    closeTrade,
  };
}
