export const INSTRUMENTS = ["EURUSD", "XAUUSD"];
export const TIMEFRAMES = ["H1", "H4"];

export const FAILURE_PATTERNS = [
  {
    id: 1,
    name: "LOW_VOLATILITY_CHOP",
    risk: "73%",
    color: "#EF4444",
    desc: "ADX < 20 + tight range consolidation",
  },
  {
    id: 2,
    name: "PRE_FOMC_DRIFT",
    risk: "68%",
    color: "#F97316",
    desc: "2h before FOMC + no clear structure",
  },
  {
    id: 3,
    name: "POST_NFP_EXHAUSTION",
    risk: "81%",
    color: "#EF4444",
    desc: "After NFP spike + counter-trend entry",
  },
  {
    id: 4,
    name: "SUMMER_LIQUIDITY_CRUNCH",
    risk: "65%",
    color: "#F97316",
    desc: "July-Aug + low volume + false breakout",
  },
  {
    id: 5,
    name: "LIQUIDITY_SWEEP_WITHOUT_BOS",
    risk: "59%",
    color: "#EAB308",
    desc: "Sweep without confirmed BOS",
  },
];
