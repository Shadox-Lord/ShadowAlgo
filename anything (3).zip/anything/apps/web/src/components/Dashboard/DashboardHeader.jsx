import React from "react";
import { Card, StatusPill, ActionPill } from "@/components/ui";
import { Play, Pause, RefreshCw } from "lucide-react";

export function DashboardHeader({
  systemState,
  onTogglePause,
  onTriggerSignal,
}) {
  return (
    <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
      <div className="flex flex-col gap-1">
        <div className="flex items-center gap-3">
          <h1 className="text-2xl font-semibold tracking-tight text-[#111827]">
            KRONOS + SHADOW AI
          </h1>
          <StatusPill
            status={systemState?.is_paused ? "BLOCKED" : "ACTIVE"}
            label={systemState?.is_paused ? "Paused" : "Operational"}
          />
        </div>
        <p className="text-[#6B7280] text-sm">
          FX Signal Engine v3.0 — Qwen-Plus · SMC · Prop Firm Hardened
        </p>
      </div>

      <div className="flex items-center gap-3">
        <ActionPill
          icon={systemState?.is_paused ? Play : Pause}
          onClick={onTogglePause}
        >
          {systemState?.is_paused ? "Resume" : "Pause"}
        </ActionPill>
        <ActionPill icon={RefreshCw} onClick={onTriggerSignal}>
          Trigger Signal
        </ActionPill>
      </div>
    </div>
  );
}

export function StatsGrid({ stats }) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {stats.map((s, i) => (
        <Card key={i} className="py-5">
          <div className="flex flex-col gap-1">
            <span className="text-xs font-medium text-[#6B7280] uppercase tracking-wider">
              {s.label}
            </span>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-semibold text-[#111827]">
                {s.value}
              </span>
              <span
                className={`text-xs font-medium ${s.up ? "text-[#10B981]" : "text-[#EF4444]"}`}
              >
                {s.trend}
              </span>
            </div>
          </div>
        </Card>
      ))}
    </div>
  );
}
