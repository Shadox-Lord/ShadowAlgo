import React from "react";
import { Card, ActionPill } from "@/components/ui";
import { RefreshCw, Link2 } from "lucide-react";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
} from "recharts";

export function CorrelationTab({ correlation, corrFetching, onRefetch }) {
  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold text-[#111827]">
            EURUSD / XAUUSD Correlation Monitor
          </h2>
          <p className="text-sm text-[#6B7280]">
            Rolling Pearson ρ · 20-candle window · Block threshold: ρ ≥ 0.7
          </p>
        </div>
        <ActionPill icon={RefreshCw} onClick={onRefetch}>
          {corrFetching ? "Fetching..." : "Refresh"}
        </ActionPill>
      </div>

      {corrFetching && (
        <div className="flex items-center justify-center py-16">
          <div className="w-8 h-8 border-2 border-[#2563EB] border-t-transparent rounded-full spin-anim" />
        </div>
      )}

      {correlation && !corrFetching && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card
            className={`border-2 ${
              correlation.correlation?.blocked
                ? "border-[#EF4444]"
                : "border-[#10B981]"
            }`}
          >
            <div className="flex flex-col items-center justify-center py-4 gap-3">
              <Link2
                size={32}
                className={
                  correlation.correlation?.blocked
                    ? "text-[#EF4444]"
                    : "text-[#10B981]"
                }
              />
              <div className="text-4xl font-black text-[#111827]">
                ρ = {correlation.correlation?.spot20c}
              </div>
              <div
                className={`text-xs font-semibold px-3 py-1.5 rounded-full text-center ${
                  correlation.correlation?.blocked
                    ? "bg-red-50 text-[#EF4444]"
                    : "bg-green-50 text-[#10B981]"
                }`}
              >
                {correlation.correlation?.verdict}
              </div>
            </div>
          </Card>

          <Card
            title="Pair Statistics"
            subtitle={`Source: ${correlation.source} · TF: ${correlation.tf}`}
          >
            <div className="flex flex-col gap-3 mt-2">
              {[
                {
                  label: "EURUSD Last Close",
                  value: correlation.eurusd?.lastClose?.toFixed(5),
                },
                {
                  label: "XAUUSD Last Close",
                  value: `$${correlation.xauusd?.lastClose?.toFixed(2)}`,
                },
                {
                  label: "Spot ρ (20c)",
                  value: correlation.correlation?.spot20c,
                },
                { label: "Full ρ", value: correlation.correlation?.full },
                {
                  label: "Direction",
                  value: correlation.correlation?.direction,
                },
                { label: "Candles Used", value: correlation.candlesUsed },
                {
                  label: "Block Threshold",
                  value: `|ρ| ≥ ${correlation.correlation?.threshold}`,
                },
                {
                  label: "Status",
                  value: correlation.correlation?.blocked
                    ? "⛔ BLOCKED"
                    : "✅ CLEAR",
                },
              ].map((r) => (
                <div
                  key={r.label}
                  className="flex justify-between items-center"
                >
                  <span className="text-sm text-[#6B7280]">{r.label}</span>
                  <span
                    className={`text-sm font-semibold ${
                      r.label === "Status"
                        ? correlation.correlation?.blocked
                          ? "text-[#EF4444]"
                          : "text-[#10B981]"
                        : "text-[#111827]"
                    }`}
                  >
                    {r.value}
                  </span>
                </div>
              ))}
            </div>
          </Card>

          <Card
            title="Rolling ρ History"
            subtitle="20-candle Pearson correlation over time"
            className="h-[380px]"
          >
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={correlation.chartData || []}>
                <defs>
                  <linearGradient id="corrGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2563EB" stopOpacity={0.1} />
                    <stop offset="95%" stopColor="#2563EB" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid
                  strokeDasharray="3 3"
                  vertical={false}
                  stroke="#F3F4F6"
                />
                <XAxis dataKey="candle" hide />
                <YAxis
                  domain={[-1, 1]}
                  tickCount={5}
                  tick={{ fontSize: 10, fill: "#9CA3AF" }}
                />
                <Tooltip
                  contentStyle={{
                    borderRadius: "8px",
                    border: "1px solid #E5E7EB",
                  }}
                  formatter={(v) => [v?.toFixed(3), "ρ"]}
                />
                <Area
                  type="monotone"
                  dataKey="rho"
                  stroke="#2563EB"
                  fill="url(#corrGrad)"
                  strokeWidth={2}
                  dot={false}
                  name="ρ"
                />
              </AreaChart>
            </ResponsiveContainer>
          </Card>
        </div>
      )}

      {!correlation && !corrFetching && (
        <div className="flex flex-col items-center justify-center py-20 text-[#9CA3AF]">
          <Link2 size={36} className="mb-3 opacity-20" />
          <p className="text-sm">Loading correlation data...</p>
        </div>
      )}
    </div>
  );
}
