import React from "react";
import { ActionPill } from "@/components/ui";
import { RefreshCw } from "lucide-react";
import { INSTRUMENTS, TIMEFRAMES } from "@/data/trading-constants";

export function SignalPanel({
  show,
  onClose,
  selectedInstrument,
  setSelectedInstrument,
  selectedTimeframe,
  setSelectedTimeframe,
  onTrigger,
  isTriggering,
  error,
}) {
  if (!show) return null;

  return (
    <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl border border-[#E5E7EB] shadow-2xl w-full max-w-sm p-6 flex flex-col gap-5">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-[#111827]">
            Trigger Signal
          </h3>
          <button
            onClick={onClose}
            className="text-[#9CA3AF] hover:text-[#111827]"
          >
            ✕
          </button>
        </div>

        <div className="flex flex-col gap-3">
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-[#6B7280] uppercase tracking-wider">
              Instrument
            </label>
            <div className="flex gap-2">
              {INSTRUMENTS.map((ins) => (
                <button
                  key={ins}
                  onClick={() => setSelectedInstrument(ins)}
                  className={`flex-1 py-2 rounded-lg text-sm font-semibold border transition-all ${
                    selectedInstrument === ins
                      ? "bg-[#111827] text-white border-[#111827]"
                      : "bg-white text-[#6B7280] border-[#E5E7EB] hover:border-[#111827]"
                  }`}
                >
                  {ins}
                </button>
              ))}
            </div>
          </div>

          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-[#6B7280] uppercase tracking-wider">
              Timeframe
            </label>
            <div className="flex gap-2">
              {TIMEFRAMES.map((tf) => (
                <button
                  key={tf}
                  onClick={() => setSelectedTimeframe(tf)}
                  className={`flex-1 py-2 rounded-lg text-sm font-semibold border transition-all ${
                    selectedTimeframe === tf
                      ? "bg-[#2563EB] text-white border-[#2563EB]"
                      : "bg-white text-[#6B7280] border-[#E5E7EB] hover:border-[#2563EB]"
                  }`}
                >
                  {tf}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="bg-[#F9FAFB] rounded-xl p-3 text-xs text-[#6B7280]">
          <p>
            ⚙️ <strong className="text-[#111827]">Risk:</strong> 0.3% equity per
            trade
          </p>
          <p>
            🛡️ <strong className="text-[#111827]">Regime:</strong> ADX ≥ 14 + ATR
            ≥ 30th pct
          </p>
          <p>
            ⏱️ <strong className="text-[#111827]">Kill:</strong> 18h time-decay
          </p>
        </div>

        {error && <p className="text-xs text-[#EF4444]">{error}</p>}

        <ActionPill
          icon={RefreshCw}
          onClick={onTrigger}
          className="w-full justify-center"
        >
          {isTriggering
            ? "Processing..."
            : `Run ${selectedInstrument} ${selectedTimeframe}`}
        </ActionPill>
      </div>
    </div>
  );
}
