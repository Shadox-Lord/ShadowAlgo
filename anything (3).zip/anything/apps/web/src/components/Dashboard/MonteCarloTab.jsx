import React from "react";
import { Card, ActionPill } from "@/components/ui";
import { Zap } from "lucide-react";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
} from "recharts";

export function MonteCarloTab({ monteCarlo, mcFetching, onRefetch }) {
  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold text-[#111827]">
            Monte Carlo Ruin Analysis
          </h2>
          <p className="text-sm text-[#6B7280]">
            5,000 simulations · 100 future trades · 0.3% risk/trade
          </p>
        </div>
        <ActionPill icon={Zap} onClick={onRefetch}>
          {mcFetching ? "Running..." : "Run Simulation"}
        </ActionPill>
      </div>

      {!monteCarlo && !mcFetching && (
        <div className="flex flex-col items-center justify-center py-24 text-[#9CA3AF]">
          <Zap size={40} className="mb-3 opacity-20" />
          <p className="text-sm font-medium">
            Click "Run Simulation" to compute probability of ruin
          </p>
          <p className="text-xs mt-1">
            Uses your real audit log history or backtest seed data
          </p>
        </div>
      )}

      {mcFetching && (
        <div className="flex flex-col items-center justify-center py-24 text-[#6B7280]">
          <div className="w-8 h-8 border-2 border-[#2563EB] border-t-transparent rounded-full spin-anim mb-3" />
          <p className="text-sm">Running 5,000 simulations...</p>
        </div>
      )}

      {monteCarlo && !mcFetching && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card
            className={`border-2 ${
              monteCarlo.verdict === "SAFE"
                ? "border-[#10B981]"
                : monteCarlo.verdict === "CAUTION"
                  ? "border-[#EAB308]"
                  : "border-[#EF4444]"
            }`}
          >
            <div className="flex flex-col items-center justify-center py-4 gap-3">
              <div
                className={`text-4xl font-black ${
                  monteCarlo.verdict === "SAFE"
                    ? "text-[#10B981]"
                    : monteCarlo.verdict === "CAUTION"
                      ? "text-[#EAB308]"
                      : "text-[#EF4444]"
                }`}
              >
                {monteCarlo.verdict}
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-[#111827]">
                  {monteCarlo.results?.probabilityOfRuin}%
                </div>
                <div className="text-xs text-[#6B7280]">
                  Probability of Ruin
                </div>
              </div>
              <div
                className={`text-xs font-semibold px-3 py-1 rounded-full ${
                  monteCarlo.verdict === "SAFE"
                    ? "bg-green-50 text-[#10B981]"
                    : monteCarlo.verdict === "CAUTION"
                      ? "bg-yellow-50 text-[#EAB308]"
                      : "bg-red-50 text-[#EF4444]"
                }`}
              >
                {monteCarlo.verdict === "SAFE"
                  ? "< 5% — Safe for live capital"
                  : monteCarlo.verdict === "CAUTION"
                    ? "5–15% — Paper trade first"
                    : "> 15% — Do NOT go live"}
              </div>
            </div>
          </Card>

          <Card
            title="Simulation Metrics"
            subtitle={`${monteCarlo.inputs?.simulations?.toLocaleString()} runs · ${monteCarlo.inputs?.dataSource}`}
          >
            <div className="flex flex-col gap-3 mt-2">
              {[
                {
                  label: "Win Rate",
                  value: `${monteCarlo.distribution?.winRate}%`,
                },
                {
                  label: "Avg Win (R)",
                  value: `+${monteCarlo.distribution?.avgWinR}R`,
                },
                {
                  label: "Avg Loss (R)",
                  value: `-${monteCarlo.distribution?.avgLossR}R`,
                },
                {
                  label: "Expectancy",
                  value: `${monteCarlo.distribution?.expectancyR}R`,
                },
                {
                  label: "Median Outcome",
                  value: `$${monteCarlo.results?.medianFinalEquity?.toLocaleString()}`,
                },
                {
                  label: "Expected Return",
                  value: `${monteCarlo.results?.expectedReturn > 0 ? "+" : ""}${monteCarlo.results?.expectedReturn}%`,
                },
                {
                  label: "P10 (Worst 10%)",
                  value: `$${monteCarlo.results?.p10FinalEquity?.toLocaleString()}`,
                },
                {
                  label: "P90 (Best 10%)",
                  value: `$${monteCarlo.results?.p90FinalEquity?.toLocaleString()}`,
                },
              ].map((r) => (
                <div
                  key={r.label}
                  className="flex justify-between items-center"
                >
                  <span className="text-sm text-[#6B7280]">{r.label}</span>
                  <span className="text-sm font-semibold text-[#111827]">
                    {r.value}
                  </span>
                </div>
              ))}
            </div>
          </Card>

          <Card
            title="Equity Fan Chart"
            subtitle="Percentile bands over 100 trades"
            className="lg:col-span-1 h-[400px]"
          >
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={monteCarlo.chartData || []}>
                <defs>
                  <linearGradient id="mcP90" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10B981" stopOpacity={0.15} />
                    <stop offset="95%" stopColor="#10B981" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="mcP10" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#EF4444" stopOpacity={0.15} />
                    <stop offset="95%" stopColor="#EF4444" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid
                  strokeDasharray="3 3"
                  vertical={false}
                  stroke="#F3F4F6"
                />
                <XAxis dataKey="trade" hide />
                <YAxis hide domain={["auto", "auto"]} />
                <Tooltip
                  contentStyle={{
                    borderRadius: "8px",
                    border: "1px solid #E5E7EB",
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="p90"
                  stroke="#10B981"
                  fill="url(#mcP90)"
                  strokeWidth={1}
                  dot={false}
                  name="P90"
                />
                <Area
                  type="monotone"
                  dataKey="p50"
                  stroke="#2563EB"
                  fill="none"
                  strokeWidth={2}
                  dot={false}
                  name="Median"
                />
                <Area
                  type="monotone"
                  dataKey="p10"
                  stroke="#EF4444"
                  fill="url(#mcP10)"
                  strokeWidth={1}
                  dot={false}
                  name="P10"
                />
              </AreaChart>
            </ResponsiveContainer>
          </Card>
        </div>
      )}
    </div>
  );
}
