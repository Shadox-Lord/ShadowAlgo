import React from "react";
import { Card, CircularRing } from "@/components/ui";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
} from "recharts";

export function OverviewTab({ closedTrades, winRate, maxDD }) {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <Card
        title="P&L History"
        subtitle="Closed trade outcomes (pips)"
        className="lg:col-span-2 h-[400px]"
      >
        <div className="h-full w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={closedTrades.slice(-20).reverse()}>
              <defs>
                <linearGradient id="colorPnL" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#2563EB" stopOpacity={0.1} />
                  <stop offset="95%" stopColor="#2563EB" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid
                strokeDasharray="3 3"
                vertical={false}
                stroke="#F3F4F6"
              />
              <XAxis dataKey="created_at" hide />
              <YAxis hide domain={["auto", "auto"]} />
              <Tooltip
                contentStyle={{
                  borderRadius: "8px",
                  border: "1px solid #E5E7EB",
                  boxShadow: "none",
                }}
                itemStyle={{ color: "#111827", fontSize: "12px" }}
              />
              <Area
                type="monotone"
                dataKey="outcome_pnl_pips"
                stroke="#2563EB"
                fillOpacity={1}
                fill="url(#colorPnL)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </Card>

      <Card title="System Health" subtitle="Real-time regime metrics">
        <div className="flex flex-wrap gap-8 justify-around py-4">
          <CircularRing value={winRate} label="Win Rate" />
          <CircularRing
            value={Math.min(100, maxDD * 5)}
            label="Daily DD"
            color="#EF4444"
          />
          <CircularRing
            value={Math.max(0, 100 - winRate)}
            label="Block Rate"
            color="#10B981"
          />
        </div>
        <div className="flex flex-col gap-3 pt-4 border-t border-[#E5E7EB]">
          <div className="flex justify-between items-center">
            <span className="text-sm text-[#6B7280]">ADX Min Threshold</span>
            <span className="text-sm font-semibold text-[#111827]">14</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-[#6B7280]">Risk / Trade</span>
            <span className="text-sm font-semibold text-[#111827]">0.3%</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-[#6B7280]">Max Consec. Losses</span>
            <span className="text-sm font-semibold text-[#111827]">3</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-[#6B7280]">Time Decay Kill</span>
            <span className="text-sm font-semibold text-[#111827]">18h</span>
          </div>
        </div>
      </Card>
    </div>
  );
}
