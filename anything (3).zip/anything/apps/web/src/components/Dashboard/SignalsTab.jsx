import React from "react";
import { Card, MetaPill, StatusPill } from "@/components/ui";
import {
  Activity,
  TrendingUp,
  TrendingDown,
  Brain,
  Fingerprint,
  CheckCircle2,
  XCircle,
} from "lucide-react";

export function SignalsTab({ activeTrades, onCloseTrade }) {
  if (activeTrades.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-[#9CA3AF]">
        <Activity size={40} className="mb-3 opacity-30" />
        <p className="text-sm">No active signals. Trigger one above.</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {activeTrades.map((log) => (
          <Card
            key={log.id}
            className="hover:border-[#D1D5DB] transition-colors"
          >
            <div className="flex justify-between items-start">
              <div className="flex flex-col gap-1">
                <div className="flex items-center gap-2">
                  <span className="text-lg font-semibold text-[#111827]">
                    {log.instrument}
                  </span>
                  <MetaPill>{log.timeframe}</MetaPill>
                </div>
                <div className="flex items-center gap-1.5">
                  {log.direction === "LONG" ? (
                    <TrendingUp size={14} className="text-[#10B981]" />
                  ) : (
                    <TrendingDown size={14} className="text-[#EF4444]" />
                  )}
                  <span
                    className={`text-sm font-bold ${log.direction === "LONG" ? "text-[#10B981]" : "text-[#EF4444]"}`}
                  >
                    {log.direction}
                  </span>
                </div>
              </div>
              <StatusPill status={log.outcome} label={log.outcome} />
            </div>

            <div className="grid grid-cols-2 gap-4 py-4">
              {[
                {
                  label: "Entry",
                  value: log.entry_price,
                  color: "#111827",
                },
                { label: "Lot", value: log.lot_size, color: "#111827" },
                {
                  label: "TP1",
                  value: log.take_profit_1,
                  color: "#10B981",
                },
                { label: "SL", value: log.stop_loss, color: "#EF4444" },
                {
                  label: "TP2",
                  value: log.take_profit_2,
                  color: "#10B981",
                },
                {
                  label: "Risk",
                  value: `${log.risk_percent}%`,
                  color: "#6B7280",
                },
              ].map((f) => (
                <div key={f.label} className="flex flex-col gap-0.5">
                  <span className="text-[10px] text-[#6B7280] uppercase tracking-wider font-semibold">
                    {f.label}
                  </span>
                  <span
                    className="text-sm font-medium"
                    style={{ color: f.color }}
                  >
                    {f.value}
                  </span>
                </div>
              ))}
            </div>

            <div className="flex items-center gap-2 pb-3 border-b border-[#E5E7EB]">
              <Brain size={12} className="text-[#6B7280] shrink-0" />
              <span className="text-[10px] text-[#6B7280] italic truncate">
                {log.smc_context || "SMC analysis pending"}
              </span>
            </div>

            <div className="flex items-center gap-2 pt-3">
              <Fingerprint size={14} className="text-[#6B7280]" />
              <span className="text-[10px] text-[#6B7280] font-mono truncate">
                {log.prompt_hash}
              </span>
              <div className="flex items-center gap-1 ml-auto">
                <button
                  onClick={() =>
                    onCloseTrade({
                      id: log.id,
                      outcome: "tp2_hit",
                      pips: 120,
                    })
                  }
                  className="p-1 hover:bg-green-50 text-[#10B981] rounded"
                  title="Mark TP2 Hit"
                >
                  <CheckCircle2 size={14} />
                </button>
                <button
                  onClick={() =>
                    onCloseTrade({
                      id: log.id,
                      outcome: "sl_hit",
                      pips: -60,
                    })
                  }
                  className="p-1 hover:bg-red-50 text-[#EF4444] rounded"
                  title="Mark SL Hit"
                >
                  <XCircle size={14} />
                </button>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
