import React from "react";
import { BarChart2 } from "lucide-react";
import { Card, ActionPill } from "@/components/ui";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceLine,
  Legend,
} from "recharts";

export function WFATab({
  wfa,
  wfaFetching,
  onRefetch,
  wfaWindows,
  setWfaWindows,
}) {
  return (
    <div className="flex flex-col gap-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-semibold text-[#111827]">
            Walk-Forward Analysis
          </h2>
          <p className="text-sm text-[#6B7280]">
            Train / Test split · 70% in-sample · 30% out-of-sample per window
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 bg-[#F9FAFB] border border-[#E5E7EB] rounded-lg px-3 py-1.5">
            <span className="text-xs text-[#6B7280]">Windows:</span>
            {[2, 3, 4, 6].map((w) => (
              <button
                key={w}
                onClick={() => setWfaWindows(w)}
                className={`text-xs font-semibold px-2 py-0.5 rounded transition-all ${
                  wfaWindows === w
                    ? "bg-[#2563EB] text-white"
                    : "text-[#6B7280] hover:text-[#111827]"
                }`}
              >
                {w}
              </button>
            ))}
          </div>
          <ActionPill icon={BarChart2} onClick={onRefetch}>
            {wfaFetching ? "Running..." : "Run WFA"}
          </ActionPill>
        </div>
      </div>

      {/* Empty state */}
      {!wfa && !wfaFetching && (
        <div className="flex flex-col items-center justify-center py-20 text-[#9CA3AF]">
          <BarChart2 size={40} className="mb-3 opacity-20" />
          <p className="text-sm font-medium">
            Click "Run WFA" to validate out-of-sample performance
          </p>
          <p className="text-xs mt-1 text-center max-w-sm">
            Splits your trade history into train/test windows and checks for
            strategy validity across time periods
          </p>
        </div>
      )}

      {/* Loading state */}
      {wfaFetching && (
        <div className="flex flex-col items-center justify-center py-20 gap-3 text-[#6B7280]">
          <div className="w-8 h-8 border-2 border-[#2563EB] border-t-transparent rounded-full wfa-spin" />
          <p className="text-sm">Running walk-forward analysis...</p>
        </div>
      )}

      {/* Results */}
      {wfa && !wfaFetching && (
        <div className="flex flex-col gap-6">
          {/* Summary banner */}
          <div
            className={`rounded-2xl border-2 p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 ${
              wfa.summary?.overallVerdict === "PASS"
                ? "border-[#10B981] bg-green-50"
                : wfa.summary?.overallVerdict === "MARGINAL"
                  ? "border-[#EAB308] bg-yellow-50"
                  : "border-[#EF4444] bg-red-50"
            }`}
          >
            <div className="flex flex-col gap-1.5">
              <div className="flex items-center gap-3">
                <span
                  className={`text-2xl font-black ${
                    wfa.summary?.overallVerdict === "PASS"
                      ? "text-[#10B981]"
                      : wfa.summary?.overallVerdict === "MARGINAL"
                        ? "text-[#EAB308]"
                        : "text-[#EF4444]"
                  }`}
                >
                  {wfa.summary?.overallVerdict}
                </span>
                <span className="text-sm font-medium text-[#6B7280]">
                  {wfa.summary?.windowsPassed}/{wfa.summary?.numWindows} windows
                  passed · {wfa.summary?.passRate} pass rate
                </span>
              </div>
              <p className="text-sm text-[#374151]">{wfa.recommendation}</p>
              <p className="text-xs text-[#6B7280]">
                Source: {wfa.summary?.dataSource} · Efficiency ratio:{" "}
                {wfa.summary?.efficiency}
              </p>
            </div>
            <div className="flex gap-6 shrink-0">
              {[
                { label: "PF", value: wfa.fullDataset?.profitFactor },
                { label: "Win%", value: `${wfa.fullDataset?.winRate}%` },
                {
                  label: "Pips",
                  value: `${wfa.fullDataset?.totalPips > 0 ? "+" : ""}${wfa.fullDataset?.totalPips}`,
                },
                { label: "Sharpe", value: wfa.fullDataset?.sharpe },
              ].map((s) => (
                <div
                  key={s.label}
                  className="flex flex-col items-center gap-0.5"
                >
                  <span className="text-xs text-[#6B7280]">{s.label}</span>
                  <span className="text-xl font-bold text-[#111827]">
                    {s.value}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Pass criteria */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              {
                label: "Min Profit Factor",
                value: `≥ ${wfa.criteria?.minProfitFactor}`,
                met:
                  wfa.fullDataset?.profitFactor >=
                  wfa.criteria?.minProfitFactor,
              },
              {
                label: "Max Drawdown",
                value: `≤ ${wfa.criteria?.maxDrawdownPct}%`,
                met: wfa.fullDataset?.maxDDPct <= wfa.criteria?.maxDrawdownPct,
              },
              {
                label: "Min Win Rate",
                value: `≥ ${wfa.criteria?.minWinRate}%`,
                met: wfa.fullDataset?.winRate >= wfa.criteria?.minWinRate,
              },
              {
                label: "Min Trades",
                value: `≥ ${wfa.criteria?.minTrades}`,
                met: wfa.fullDataset?.trades >= wfa.criteria?.minTrades,
              },
            ].map((c) => (
              <Card
                key={c.label}
                className={`py-3 border ${c.met ? "border-[#10B981]" : "border-[#EF4444]"}`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs text-[#6B7280]">{c.label}</span>
                  <span
                    className={`text-xs font-bold ${c.met ? "text-[#10B981]" : "text-[#EF4444]"}`}
                  >
                    {c.met ? "✅ PASS" : "❌ FAIL"}
                  </span>
                </div>
                <span className="text-sm font-semibold text-[#111827]">
                  {c.value}
                </span>
              </Card>
            ))}
          </div>

          {/* Window result cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
            {(wfa.windows || []).map((w) => (
              <Card
                key={w.window}
                className={`border-l-4 ${w.pass ? "border-l-[#10B981]" : "border-l-[#EF4444]"}`}
              >
                <div className="flex justify-between items-center mb-3">
                  <span className="text-sm font-bold text-[#111827]">
                    Window {w.window}
                  </span>
                  <span
                    className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                      w.pass
                        ? "bg-green-50 text-[#10B981]"
                        : "bg-red-50 text-[#EF4444]"
                    }`}
                  >
                    {w.pass ? "PASS" : "FAIL"}
                  </span>
                </div>
                <p className="text-[10px] text-[#9CA3AF] mb-3">
                  {w.startDate} → {w.endDate}
                </p>
                <div className="grid grid-cols-2 gap-2 text-left">
                  {[
                    {
                      label: "IS PF",
                      value: w.inSample?.profitFactor,
                      pass: w.inSample?.profitFactor >= 1.3,
                    },
                    {
                      label: "OOS PF",
                      value: w.outOfSample?.profitFactor,
                      pass: w.outOfSample?.profitFactor >= 1.3,
                    },
                    {
                      label: "IS Win%",
                      value: `${w.inSample?.winRate}%`,
                      pass: w.inSample?.winRate >= 50,
                    },
                    {
                      label: "OOS Win%",
                      value: `${w.outOfSample?.winRate}%`,
                      pass: w.outOfSample?.winRate >= 50,
                    },
                  ].map((m) => (
                    <div key={m.label} className="flex flex-col gap-0.5">
                      <span className="text-[9px] text-[#9CA3AF] uppercase font-bold">
                        {m.label}
                      </span>
                      <span
                        className={`text-xs font-semibold ${m.pass ? "text-[#10B981]" : "text-[#EF4444]"}`}
                      >
                        {m.value}
                      </span>
                    </div>
                  ))}
                </div>
              </Card>
            ))}
          </div>

          {/* IS vs OOS Profit Factor bar chart */}
          <Card
            title="In-Sample vs Out-of-Sample Profit Factor"
            subtitle="Minimum threshold = 1.3 (red line)"
            className="h-[300px]"
          >
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={wfa.chartData || []} barGap={4}>
                <CartesianGrid
                  strokeDasharray="3 3"
                  vertical={false}
                  stroke="#F3F4F6"
                />
                <XAxis
                  dataKey="window"
                  tick={{ fontSize: 11, fill: "#9CA3AF" }}
                />
                <YAxis
                  tick={{ fontSize: 10, fill: "#9CA3AF" }}
                  domain={[0, "auto"]}
                />
                <Tooltip
                  contentStyle={{
                    borderRadius: "8px",
                    border: "1px solid #E5E7EB",
                  }}
                />
                <Legend wrapperStyle={{ fontSize: "11px" }} />
                <ReferenceLine
                  y={1.3}
                  stroke="#EF4444"
                  strokeDasharray="4 4"
                  label={{ value: "Min 1.3", fill: "#EF4444", fontSize: 10 }}
                />
                <Bar
                  dataKey="inSamplePF"
                  name="In-Sample PF"
                  fill="#2563EB"
                  radius={[4, 4, 0, 0]}
                />
                <Bar
                  dataKey="oofPF"
                  name="Out-of-Sample PF"
                  fill="#10B981"
                  radius={[4, 4, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </Card>

          {/* Cumulative P&L curve */}
          <Card
            title="Cumulative P&L Curve"
            subtitle="All trades in chronological order"
            className="h-[260px]"
          >
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={wfa.cumulativeChart || []}>
                <defs>
                  <linearGradient id="cumPnLGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2563EB" stopOpacity={0.12} />
                    <stop offset="95%" stopColor="#2563EB" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid
                  strokeDasharray="3 3"
                  vertical={false}
                  stroke="#F3F4F6"
                />
                <XAxis
                  dataKey="trade"
                  tick={{ fontSize: 10, fill: "#9CA3AF" }}
                  label={{
                    value: "Trade #",
                    position: "insideBottom",
                    offset: -2,
                    fontSize: 10,
                    fill: "#9CA3AF",
                  }}
                />
                <YAxis tick={{ fontSize: 10, fill: "#9CA3AF" }} />
                <Tooltip
                  contentStyle={{
                    borderRadius: "8px",
                    border: "1px solid #E5E7EB",
                  }}
                  formatter={(v) => [
                    `${v > 0 ? "+" : ""}${v}p`,
                    "Cumulative P&L",
                  ]}
                />
                <ReferenceLine y={0} stroke="#E5E7EB" />
                <Area
                  type="monotone"
                  dataKey="pips"
                  stroke="#2563EB"
                  fill="url(#cumPnLGrad)"
                  strokeWidth={2}
                  dot={false}
                  name="P&L (pips)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </Card>
        </div>
      )}

      <style jsx global>{`
        .wfa-spin { animation: wfa-spin-kf 0.8s linear infinite; }
        @keyframes wfa-spin-kf { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
}
