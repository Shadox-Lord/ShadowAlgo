import React from "react";
import { Card } from "@/components/ui";
import { CheckCircle2 } from "lucide-react";
import { FAILURE_PATTERNS } from "@/data/trading-constants";

export function RiskTab() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <Card
        title="Risk Architecture"
        subtitle="ShadowAlgo v3.0 — Alpha Rehabilitation"
      >
        <div className="flex flex-col gap-4">
          {[
            { label: "Risk / Trade", value: "0.3% equity", ok: true },
            { label: "SL Placement", value: "1.5 × ATR(14)", ok: true },
            {
              label: "ADX Regime Gate",
              value: "≥ 14 (Hard Block)",
              ok: true,
            },
            {
              label: "ATR Percentile Gate",
              value: "≥ 30th pct",
              ok: true,
            },
            { label: "Uncertainty Block", value: "> 0.65", ok: true },
            {
              label: "Breakeven Buffer",
              value: "+1.5 pips after 1:1 RR",
              ok: true,
            },
            {
              label: "Partial TP",
              value: "50% close at 1:2 RR",
              ok: true,
            },
            { label: "Time-Decay Kill", value: "18h max hold", ok: true },
            {
              label: "Consec. Loss Kill",
              value: "3 losses → halt",
              ok: true,
            },
            {
              label: "Daily Loss Halt",
              value: "4.5% daily DD",
              ok: true,
            },
            {
              label: "Weekly Loss Halt",
              value: "8% weekly DD",
              ok: true,
            },
            {
              label: "Supported Assets",
              value: "EURUSD, XAUUSD",
              ok: true,
            },
          ].map((r) => (
            <div key={r.label} className="flex items-center justify-between">
              <span className="text-sm text-[#6B7280]">{r.label}</span>
              <div className="flex items-center gap-1.5">
                <span className="text-sm font-semibold text-[#111827]">
                  {r.value}
                </span>
                <CheckCircle2 size={12} className="text-[#10B981]" />
              </div>
            </div>
          ))}
        </div>
      </Card>

      <Card
        title="Few-Shot Failure Signatures"
        subtitle="Patch 3 — Autopsy Injection (loss rate → block)"
      >
        <div className="flex flex-col gap-3">
          {FAILURE_PATTERNS.map((p) => (
            <div
              key={p.id}
              className="flex flex-col gap-1 p-3 rounded-xl bg-[#F9FAFB] border border-[#E5E7EB]"
            >
              <div className="flex items-center justify-between">
                <span
                  className="text-xs font-bold font-mono"
                  style={{ color: p.color }}
                >
                  {p.name}
                </span>
                <span className="text-xs font-bold" style={{ color: p.color }}>
                  Loss: {p.risk}
                </span>
              </div>
              <p className="text-[11px] text-[#6B7280]">
                {p.desc} — <em>DO NOT TRADE</em>
              </p>
            </div>
          ))}
          <p className="text-[10px] text-[#9CA3AF] pt-2">
            These patterns are injected as few-shot context into every Qwen-Plus
            LLM call.
          </p>
        </div>
      </Card>
    </div>
  );
}
