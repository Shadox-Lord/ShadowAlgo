import React from "react";

const TAB_LABELS = {
  overview: "Overview",
  signals: "Signals",
  "audit-log": "Audit Log",
  risk: "Risk",
  "monte-carlo": "Monte Carlo",
  correlation: "Correlation",
  wfa: "Walk-Forward",
  news: "📰 News",
};

export function TabNavigation({ activeTab, onTabChange }) {
  const tabs = Object.keys(TAB_LABELS);

  return (
    <div className="flex border-b border-[#E5E7EB] w-full overflow-x-auto">
      {tabs.map((tab) => (
        <button
          key={tab}
          onClick={() => onTabChange(tab)}
          className={`px-4 pb-3 text-sm transition-all whitespace-nowrap ${
            activeTab === tab
              ? "text-[#111827] font-semibold border-b-2 border-[#2563EB] -mb-[1px]"
              : "text-[#6B7280] font-normal border-b-2 border-transparent hover:text-[#111827]"
          }`}
        >
          {TAB_LABELS[tab]}
        </button>
      ))}
    </div>
  );
}
