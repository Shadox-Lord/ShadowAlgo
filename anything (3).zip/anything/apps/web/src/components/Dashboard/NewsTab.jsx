import React from "react";
import { RefreshCw, AlertTriangle, Radio } from "lucide-react";
import { format } from "date-fns";
import { Card, ActionPill } from "@/components/ui";

export function NewsTab({ newsCalendar, onRefetch }) {
  return (
    <div className="flex flex-col gap-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-semibold text-[#111827]">
            Economic Calendar
          </h2>
          <p className="text-sm text-[#6B7280]">
            Live feed · Source: {newsCalendar?.source || "loading..."} ·
            Auto-refreshes every 5 min
          </p>
        </div>
        <div className="flex items-center gap-3">
          {newsCalendar?.tradingBlocked && (
            <div className="flex items-center gap-1.5 px-3 py-1.5 bg-red-50 border border-[#EF4444] rounded-lg">
              <Radio size={12} className="text-[#EF4444]" />
              <span className="text-xs font-bold text-[#EF4444]">
                BLACKOUT ACTIVE
              </span>
            </div>
          )}
          <ActionPill icon={RefreshCw} onClick={onRefetch}>
            Refresh
          </ActionPill>
        </div>
      </div>

      {/* Summary stats */}
      {newsCalendar && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            {
              label: "Total Events (48h)",
              value: newsCalendar.totalEvents ?? 0,
              color: "#111827",
            },
            {
              label: "High Impact",
              value: newsCalendar.highImpactCount ?? 0,
              color: "#EF4444",
            },
            {
              label: "Active Blackouts",
              value: newsCalendar.activeBlackouts ?? 0,
              color:
                (newsCalendar.activeBlackouts ?? 0) > 0 ? "#EF4444" : "#10B981",
            },
            {
              label: "Trading Status",
              value: newsCalendar.tradingBlocked ? "⛔ BLOCKED" : "✅ CLEAR",
              color: newsCalendar.tradingBlocked ? "#EF4444" : "#10B981",
            },
          ].map((s) => (
            <Card key={s.label} className="py-4">
              <span className="text-xs text-[#6B7280] uppercase tracking-wider font-medium block mb-1">
                {s.label}
              </span>
              <div className="text-xl font-bold" style={{ color: s.color }}>
                {s.value}
              </div>
            </Card>
          ))}
        </div>
      )}

      {/* Next high-impact event banner */}
      {newsCalendar?.nextHighImpact && (
        <div className="flex items-start gap-3 p-4 rounded-xl bg-[#FFF7ED] border border-[#F97316]">
          <AlertTriangle size={18} className="text-[#F97316] shrink-0 mt-0.5" />
          <div className="flex flex-col gap-0.5">
            <div>
              <span className="text-sm font-semibold text-[#C2410C]">
                Next High-Impact Event:{" "}
              </span>
              <span className="text-sm text-[#9A3412]">
                {newsCalendar.nextHighImpact.name} (
                {newsCalendar.nextHighImpact.country})
              </span>
            </div>
            <span className="text-xs text-[#C2410C]">
              {Math.abs(newsCalendar.nextHighImpact.minutesAway)} min{" "}
              {newsCalendar.nextHighImpact.minutesAway > 0 ? "away" : "ago"} ·{" "}
              Blackout: ±30 min window active
            </span>
          </div>
        </div>
      )}

      {/* Empty state */}
      {(!newsCalendar || !newsCalendar.events?.length) && (
        <div className="flex flex-col items-center justify-center py-16 text-[#9CA3AF]">
          <RefreshCw size={36} className="mb-3 opacity-20" />
          <p className="text-sm">Loading economic calendar...</p>
        </div>
      )}

      {/* Events table */}
      {newsCalendar?.events?.length > 0 && (
        <Card className="overflow-hidden p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead className="bg-[#F9FAFB] border-b border-[#E5E7EB]">
                <tr>
                  {[
                    "Time (UTC)",
                    "Event",
                    "Country",
                    "Impact",
                    "Forecast",
                    "Previous",
                    "Status",
                  ].map((h) => (
                    <th
                      key={h}
                      className="px-4 py-3 text-xs font-semibold text-[#6B7280] uppercase tracking-wider whitespace-nowrap"
                    >
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E5E7EB]">
                {newsCalendar.events.map((e, i) => (
                  <tr
                    key={i}
                    className={`hover:bg-[#F9FAFB] transition-colors ${e.isBlackout ? "bg-red-50" : ""}`}
                  >
                    <td className="px-4 py-3 text-sm text-[#6B7280] whitespace-nowrap font-mono">
                      {e.datetime
                        ? format(new Date(e.datetime), "MMM dd HH:mm")
                        : "—"}
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={`text-sm font-medium ${e.isHighImpact ? "text-[#111827]" : "text-[#6B7280]"}`}
                      >
                        {e.name}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span className="text-xs font-bold text-[#6B7280] uppercase">
                        {e.country}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                          e.impact === "high"
                            ? "bg-red-50 text-[#EF4444]"
                            : e.impact === "medium"
                              ? "bg-orange-50 text-[#F97316]"
                              : "bg-gray-50 text-[#9CA3AF]"
                        }`}
                      >
                        {(e.impact || "low").toUpperCase()}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-sm text-[#6B7280]">
                      {e.forecast ?? "—"}
                    </td>
                    <td className="px-4 py-3 text-sm text-[#6B7280]">
                      {e.previous ?? "—"}
                    </td>
                    <td className="px-4 py-3">
                      {e.isBlackout ? (
                        <span className="text-xs font-bold text-[#EF4444] flex items-center gap-1">
                          <Radio size={10} /> BLACKOUT
                        </span>
                      ) : e.minutesAway < 0 ? (
                        <span className="text-xs text-[#9CA3AF]">Passed</span>
                      ) : (
                        <span className="text-xs text-[#10B981]">
                          In {e.minutesAway}m
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}
    </div>
  );
}
