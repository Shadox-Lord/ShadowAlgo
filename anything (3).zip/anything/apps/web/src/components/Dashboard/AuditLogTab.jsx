import React from "react";
import { Card, StatusPill } from "@/components/ui";
import { format } from "date-fns";
import { TrendingUp, TrendingDown } from "lucide-react";

export function AuditLogTab({ logs }) {
  return (
    <Card className="overflow-hidden p-0">
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead className="bg-[#F9FAFB] border-b border-[#E5E7EB]">
            <tr>
              {[
                "Timestamp",
                "Instrument",
                "Status",
                "ADX / Unc",
                "Direction",
                "Outcome",
                "P&L (p)",
              ].map((h) => (
                <th
                  key={h}
                  className="px-5 py-4 text-xs font-semibold text-[#6B7280] uppercase tracking-wider whitespace-nowrap"
                >
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-[#E5E7EB]">
            {logs.map((log) => (
              <tr key={log.id} className="hover:bg-[#F9FAFB] transition-colors">
                <td className="px-5 py-4 text-sm text-[#6B7280] whitespace-nowrap">
                  {format(new Date(log.created_at), "MMM dd, HH:mm")}
                </td>
                <td className="px-5 py-4">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-semibold text-[#111827]">
                      {log.instrument}
                    </span>
                    <span className="text-[10px] font-medium text-[#6B7280] px-1.5 py-0.5 rounded border border-[#E5E7EB]">
                      {log.timeframe}
                    </span>
                  </div>
                </td>
                <td className="px-5 py-4">
                  <StatusPill
                    status={log.signal_status}
                    label={log.signal_status}
                  />
                </td>
                <td className="px-5 py-4">
                  <div className="flex items-center gap-3">
                    <div className="flex flex-col">
                      <span className="text-[10px] text-[#6B7280] uppercase font-bold">
                        ADX
                      </span>
                      <span
                        className={`text-xs font-medium ${log.adx_value >= 14 ? "text-[#10B981]" : "text-[#EF4444]"}`}
                      >
                        {log.adx_value?.toFixed(1)}
                      </span>
                    </div>
                    <div className="flex flex-col">
                      <span className="text-[10px] text-[#6B7280] uppercase font-bold">
                        UNC
                      </span>
                      <span
                        className={`text-xs font-medium ${log.uncertainty_score <= 0.65 ? "text-[#10B981]" : "text-[#EF4444]"}`}
                      >
                        {log.uncertainty_score?.toFixed(2)}
                      </span>
                    </div>
                  </div>
                </td>
                <td className="px-5 py-4">
                  {log.direction ? (
                    <div className="flex items-center gap-1">
                      {log.direction === "LONG" ? (
                        <TrendingUp size={12} className="text-[#10B981]" />
                      ) : (
                        <TrendingDown size={12} className="text-[#EF4444]" />
                      )}
                      <span
                        className={`text-xs font-semibold ${log.direction === "LONG" ? "text-[#10B981]" : "text-[#EF4444]"}`}
                      >
                        {log.direction}
                      </span>
                    </div>
                  ) : (
                    <span className="text-xs text-[#D1D5DB]">—</span>
                  )}
                </td>
                <td className="px-5 py-4">
                  <span
                    className={`text-xs font-medium capitalize ${
                      log.outcome === "tp2_hit" || log.outcome === "tp1_hit"
                        ? "text-[#10B981]"
                        : log.outcome === "sl_hit"
                          ? "text-[#EF4444]"
                          : "text-[#6B7280]"
                    }`}
                  >
                    {log.outcome}
                  </span>
                </td>
                <td className="px-5 py-4 text-right">
                  <span
                    className={`text-sm font-semibold ${
                      log.outcome_pnl_pips > 0
                        ? "text-[#10B981]"
                        : log.outcome_pnl_pips < 0
                          ? "text-[#EF4444]"
                          : "text-[#111827]"
                    }`}
                  >
                    {log.outcome_pnl_pips != null
                      ? `${log.outcome_pnl_pips > 0 ? "+" : ""}${log.outcome_pnl_pips}`
                      : "—"}
                  </span>
                </td>
              </tr>
            ))}
            {logs.length === 0 && (
              <tr>
                <td
                  colSpan={7}
                  className="px-5 py-12 text-center text-sm text-[#9CA3AF]"
                >
                  No audit records yet. Trigger a signal to begin.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </Card>
  );
}
