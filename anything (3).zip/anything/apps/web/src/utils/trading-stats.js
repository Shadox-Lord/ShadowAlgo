export function calculateDerivedStats(systemState, logs) {
  const equity = systemState?.current_equity || 100000;
  const dailyStartEq = systemState?.daily_start_equity || 100000;
  const dailyDD = (((dailyStartEq - equity) / dailyStartEq) * 100).toFixed(2);

  const activeTrades = logs.filter(
    (l) => l.outcome === "pending" && l.signal_status === "ACTIVE",
  );

  const closedTrades = logs.filter((l) => l.outcome !== "pending");

  const wins = closedTrades.filter(
    (l) => l.outcome === "tp1_hit" || l.outcome === "tp2_hit",
  ).length;

  const winRate = closedTrades.length
    ? Math.round((wins / closedTrades.length) * 100)
    : 0;

  const totalPips = closedTrades.reduce(
    (s, l) => s + (l.outcome_pnl_pips || 0),
    0,
  );

  const maxDD = Math.max(0, parseFloat(dailyDD));

  return {
    equity,
    dailyStartEq,
    dailyDD,
    activeTrades,
    closedTrades,
    wins,
    winRate,
    totalPips,
    maxDD,
  };
}

export function getStatsCards(derivedStats) {
  const { equity, dailyDD, activeTrades, totalPips, closedTrades } =
    derivedStats;

  return [
    {
      label: "Current Equity",
      value: `$${equity.toLocaleString()}`,
      trend: `Daily DD: ${dailyDD}%`,
      up: parseFloat(dailyDD) < 2,
    },
    {
      label: "Active Trades",
      value: activeTrades.length,
      trend: "Live positions",
      up: true,
    },
    {
      label: "Total P&L",
      value: `${totalPips > 0 ? "+" : ""}${totalPips.toFixed(1)}p`,
      trend: `${closedTrades.length} closed`,
      up: totalPips >= 0,
    },
  ];
}
