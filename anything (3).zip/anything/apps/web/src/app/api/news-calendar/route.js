/**
 * Live Economic Calendar Feed
 * Primary: TwelveData Economic Calendar API
 * Fallback: ForexFactory RSS scrape
 * GET /api/news-calendar?hours=24&impact=high
 */

const HIGH_IMPACT_KEYWORDS = [
  "NFP",
  "Non-Farm",
  "CPI",
  "Inflation",
  "FOMC",
  "Fed Rate",
  "Federal Reserve",
  "Interest Rate",
  "GDP",
  "Employment",
  "Unemployment",
  "ECB",
  "BOE",
  "BOJ",
  "Retail Sales",
  "PMI",
  "ISM",
  "PPI",
  "Trade Balance",
  "Payroll",
];

/**
 * Fetch from TwelveData Economic Calendar
 */
async function fetchTwelveDataCalendar(hoursAhead = 48) {
  const apiKey = process.env.TWELVE_DATA_API_KEY;
  if (!apiKey) return null;

  try {
    const now = new Date();
    const end = new Date(now.getTime() + hoursAhead * 60 * 60 * 1000);
    const start = new Date(now.getTime() - 2 * 60 * 60 * 1000); // 2h back too

    const startStr = start.toISOString().slice(0, 10);
    const endStr = end.toISOString().slice(0, 10);

    const url = `https://api.twelvedata.com/economic_calendar?start_date=${startStr}&end_date=${endStr}&apikey=${apiKey}`;
    const res = await fetch(url, { next: { revalidate: 300 } }); // cache 5 min
    if (!res.ok) return null;

    const json = await res.json();
    if (!json.result || !Array.isArray(json.result)) return null;

    return json.result.map((e) => ({
      name: e.event || e.name || "Unknown",
      country: e.country || "US",
      impact: e.importance || "medium",
      datetime: e.date || e.datetime,
      actual: e.actual || null,
      forecast: e.estimate || null,
      previous: e.previous || null,
      source: "twelvedata",
    }));
  } catch (err) {
    console.warn("[NewsCalendar] TwelveData failed:", err.message);
    return null;
  }
}

/**
 * Scrape ForexFactory RSS calendar feed (public, no auth required)
 */
async function fetchForexFactoryFeed() {
  try {
    const url = "https://nfs.faireconomy.media/ff_calendar_thisweek.json";
    const res = await fetch(url, {
      headers: { Accept: "application/json" },
      next: { revalidate: 600 }, // cache 10 min
    });
    if (!res.ok) return null;

    const events = await res.json();
    if (!Array.isArray(events)) return null;

    return events.map((e) => ({
      name: e.title || "Unknown",
      country: e.country || "US",
      impact: e.impact || "medium",
      datetime: e.date || "",
      actual: e.actual || null,
      forecast: e.forecast || null,
      previous: e.previous || null,
      source: "forexfactory",
    }));
  } catch (err) {
    console.warn("[NewsCalendar] ForexFactory failed:", err.message);
    return null;
  }
}

/**
 * Generate hardcoded schedule as final fallback
 * Based on typical weekly high-impact forex events
 */
function getHardcodedSchedule() {
  const now = new Date();
  const events = [];

  // Generate next 7 days of hardcoded events
  for (let dayOffset = 0; dayOffset < 7; dayOffset++) {
    const day = new Date(now);
    day.setUTCDate(day.getUTCDate() + dayOffset);
    const dow = day.getUTCDay(); // 0=Sun, 1=Mon ... 5=Fri

    if (dow === 0 || dow === 6) continue; // skip weekends

    const dateStr = day.toISOString().slice(0, 10);

    // Monday — Asia open risk
    if (dow === 1) {
      events.push({
        name: "Asia Market Open",
        country: "JP",
        impact: "medium",
        datetime: `${dateStr}T00:00:00Z`,
        source: "hardcoded",
      });
    }

    // Tuesday — typical RBA/BOC
    if (dow === 2) {
      events.push({
        name: "RBA Rate Statement",
        country: "AU",
        impact: "high",
        datetime: `${dateStr}T03:30:00Z`,
        source: "hardcoded",
      });
    }

    // Wednesday — weekly US inventories / FOMC minutes (alternate)
    if (dow === 3) {
      events.push({
        name: "US Crude Oil Inventories",
        country: "US",
        impact: "medium",
        datetime: `${dateStr}T14:30:00Z`,
        source: "hardcoded",
      });
    }

    // Thursday — ECB / BOE press conferences
    if (dow === 4) {
      events.push({
        name: "ECB Press Conference",
        country: "EU",
        impact: "high",
        datetime: `${dateStr}T12:45:00Z`,
        source: "hardcoded",
      });
      events.push({
        name: "US Initial Jobless Claims",
        country: "US",
        impact: "high",
        datetime: `${dateStr}T12:30:00Z`,
        source: "hardcoded",
      });
    }

    // Friday — NFP (1st Fri of month), always show US data
    if (dow === 5) {
      events.push({
        name: "US NFP / Employment Data",
        country: "US",
        impact: "high",
        datetime: `${dateStr}T12:30:00Z`,
        source: "hardcoded",
      });
      events.push({
        name: "Weekly Market Close",
        country: "US",
        impact: "medium",
        datetime: `${dateStr}T21:00:00Z`,
        source: "hardcoded",
      });
    }
  }

  return events;
}

/**
 * Determine if a given event is currently in a blackout window
 */
function isInBlackout(
  event,
  windowMinutesBefore = 30,
  windowMinutesAfter = 30,
) {
  try {
    const eventTime = new Date(event.datetime);
    if (isNaN(eventTime.getTime())) return false;
    const now = new Date();
    const diffMs = eventTime.getTime() - now.getTime();
    const diffMin = diffMs / 60000;
    return diffMin >= -windowMinutesAfter && diffMin <= windowMinutesBefore;
  } catch {
    return false;
  }
}

/**
 * Classify impact level consistently
 */
function normaliseImpact(rawImpact) {
  const s = String(rawImpact || "").toLowerCase();
  if (s === "high" || s === "3" || s === "red") return "high";
  if (s === "medium" || s === "2" || s === "orange") return "medium";
  return "low";
}

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const hoursAhead = parseInt(searchParams.get("hours") || "48");
    const impactFilter = searchParams.get("impact") || "all"; // all | high | medium

    // Try live sources in priority order
    let raw = await fetchTwelveDataCalendar(hoursAhead);
    let source = "twelvedata";

    if (!raw) {
      raw = await fetchForexFactoryFeed();
      source = "forexfactory";
    }

    if (!raw) {
      raw = getHardcodedSchedule();
      source = "hardcoded";
    }

    // Normalise and filter
    const now = new Date();
    const cutoff = new Date(now.getTime() + hoursAhead * 60 * 60 * 1000);
    const lookback = new Date(now.getTime() - 2 * 60 * 60 * 1000);

    let events = raw
      .filter((e) => {
        const t = new Date(e.datetime);
        return !isNaN(t.getTime()) && t >= lookback && t <= cutoff;
      })
      .map((e) => ({
        ...e,
        impact: normaliseImpact(e.impact),
        isBlackout: isInBlackout(e),
        isHighImpact:
          HIGH_IMPACT_KEYWORDS.some((kw) =>
            (e.name || "").toLowerCase().includes(kw.toLowerCase()),
          ) || normaliseImpact(e.impact) === "high",
        minutesAway: Math.round((new Date(e.datetime) - now) / 60000),
      }))
      .sort((a, b) => new Date(a.datetime) - new Date(b.datetime));

    if (impactFilter === "high") {
      events = events.filter((e) => e.isHighImpact);
    } else if (impactFilter === "medium") {
      events = events.filter((e) => e.impact !== "low");
    }

    const activeBlackouts = events.filter(
      (e) => e.isBlackout && e.isHighImpact,
    );
    const nextHighImpact = events.find(
      (e) => e.isHighImpact && e.minutesAway > 0,
    );

    return Response.json({
      source,
      fetchedAt: now.toISOString(),
      hoursWindow: hoursAhead,
      totalEvents: events.length,
      highImpactCount: events.filter((e) => e.isHighImpact).length,
      activeBlackouts: activeBlackouts.length,
      tradingBlocked: activeBlackouts.length > 0,
      nextHighImpact: nextHighImpact || null,
      events,
    });
  } catch (err) {
    console.error("[NewsCalendar]", err);
    return Response.json({ error: err.message }, { status: 500 });
  }
}
