import { fetchOHLCV } from "@/app/api/utils/twelvedata";

/**
 * Dynamic Correlation Monitor
 * Computes rolling Pearson ρ between EURUSD and XAUUSD returns
 * Block threshold: ρ > 0.7 over last 20 candles
 */

const BLOCK_THRESHOLD = 0.7;
const ROLLING_PERIOD = 20;

/**
 * Pearson correlation coefficient between two numeric arrays
 */
function pearsonCorrelation(x, y) {
  const n = Math.min(x.length, y.length);
  if (n < 4) return 0;
  const xa = x.slice(-n),
    ya = y.slice(-n);
  const mx = xa.reduce((s, v) => s + v, 0) / n;
  const my = ya.reduce((s, v) => s + v, 0) / n;
  let num = 0,
    dx2 = 0,
    dy2 = 0;
  for (let i = 0; i < n; i++) {
    const ex = xa[i] - mx,
      ey = ya[i] - my;
    num += ex * ey;
    dx2 += ex * ex;
    dy2 += ey * ey;
  }
  const denom = Math.sqrt(dx2 * dy2);
  return denom === 0 ? 0 : num / denom;
}

/**
 * Compute log-returns from close prices
 */
function logReturns(candles) {
  const returns = [];
  for (let i = 1; i < candles.length; i++) {
    returns.push(Math.log(candles[i].close / candles[i - 1].close));
  }
  return returns;
}

/**
 * Compute rolling correlation over windows of `period`
 */
function rollingCorrelation(r1, r2, period) {
  const n = Math.min(r1.length, r2.length);
  const result = [];
  for (let i = period; i <= n; i++) {
    const rho = pearsonCorrelation(
      r1.slice(i - period, i),
      r2.slice(i - period, i),
    );
    result.push(parseFloat(rho.toFixed(4)));
  }
  return result;
}

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const tf = searchParams.get("tf") || "H4";
    const days = parseInt(searchParams.get("days") || "7"); // NEW: rolling window in days
    const candles = parseInt(searchParams.get("candles") || "60");

    // Determine how many candles needed for rolling window
    // H4 = 6 candles/day, H1 = 24 candles/day
    const candlesPerDay = tf === "H1" ? 24 : 6;
    const rollingCandles = Math.max(
      candles,
      days * candlesPerDay + ROLLING_PERIOD,
    );

    // Fetch both pairs in parallel — more candles for 30-day view
    const [eu, xau] = await Promise.all([
      fetchOHLCV("EURUSD", tf, rollingCandles),
      fetchOHLCV("XAUUSD", tf, rollingCandles),
    ]);

    // Align candle arrays to same length
    const len = Math.min(eu.candles.length, xau.candles.length);
    const euRet = logReturns(eu.candles.slice(-len));
    const xauRet = logReturns(xau.candles.slice(-len));

    // Spot (last 20c) and full correlation
    const spotRho = pearsonCorrelation(
      euRet.slice(-ROLLING_PERIOD),
      xauRet.slice(-ROLLING_PERIOD),
    );
    const fullRho = pearsonCorrelation(euRet, xauRet);

    // Rolling 20-candle correlation over full history
    const rollingAll = rollingCorrelation(euRet, xauRet, ROLLING_PERIOD);

    // Rolling 30-day correlation (larger window)
    const rollingPeriod30d = days * candlesPerDay;
    const rolling30d =
      rollingCandles >= rollingPeriod30d + 5
        ? rollingCorrelation(
            euRet,
            xauRet,
            Math.min(rollingPeriod30d, euRet.length - 1),
          )
        : [];

    // Build chart data: each candle gets a rolling ρ value + 30d ρ value
    const chartData = rollingAll.map((rho, i) => ({
      candle: i + ROLLING_PERIOD,
      rho,
      // map 30d rolling into same timeline if available
      rho30d: rolling30d.length > i ? rolling30d[i] : null,
    }));

    const isBlocked = Math.abs(spotRho) >= BLOCK_THRESHOLD;
    const correlation = parseFloat(spotRho.toFixed(4));
    const direction =
      correlation > 0.1
        ? "Positive"
        : correlation < -0.1
          ? "Negative"
          : "Near Zero";

    // 30-day average rho
    const avg30dRho =
      rolling30d.length > 0
        ? parseFloat(
            (
              rolling30d.slice(-rolling30d.length).reduce((s, v) => s + v, 0) /
              rolling30d.length
            ).toFixed(4),
          )
        : null;

    return Response.json({
      tf,
      days,
      candlesUsed: len,
      source: eu.source,
      eurusd: { lastClose: eu.currentPrice },
      xauusd: { lastClose: xau.currentPrice },
      correlation: {
        spot20c: correlation,
        full: parseFloat(fullRho.toFixed(4)),
        avg30d: avg30dRho,
        direction,
        blocked: isBlocked,
        threshold: BLOCK_THRESHOLD,
        verdict: isBlocked
          ? `⛔ CORRELATION BLOCKED (ρ=${correlation} ≥ ${BLOCK_THRESHOLD}) — Do not run both pairs simultaneously`
          : `✅ Correlation OK (ρ=${correlation} < ${BLOCK_THRESHOLD}) — Pairs can trade independently`,
      },
      chartData,
    });
  } catch (err) {
    console.error("[Correlation]", err);
    return Response.json({ error: err.message }, { status: 500 });
  }
}
