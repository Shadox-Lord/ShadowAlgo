/**
 * Walk-Forward Analysis Engine
 * Splits audit log into IN-SAMPLE (train) + OUT-OF-SAMPLE (test) windows
 * Validates strategy performance across rolling time periods
 * GET /api/wfa?windows=4&minTrades=5
 */

import sql from "@/app/api/utils/sql";

const PASS_CRITERIA = {
  minProfitFactor: 1.3,
  maxDrawdownPct: 20,
  minWinRate: 50,
  minTrades: 5,
};

/**
 * Calculate key metrics from a set of closed trade records
 */
function calcMetrics(trades) {
  if (!trades || trades.length === 0) {
    return {
      trades: 0,
      winRate: 0,
      profitFactor: 0,
      totalPips: 0,
      maxDD: 0,
      sharpe: 0,
    };
  }

  const closed = trades.filter((t) => t.outcome !== "pending");
  if (closed.length === 0)
    return {
      trades: 0,
      winRate: 0,
      profitFactor: 0,
      totalPips: 0,
      maxDD: 0,
      sharpe: 0,
    };

  const wins = closed.filter(
    (t) => t.outcome === "tp1_hit" || t.outcome === "tp2_hit",
  );
  const losses = closed.filter(
    (t) =>
      t.outcome === "sl_hit" ||
      t.outcome === "kill_switch" ||
      t.outcome === "timeout",
  );

  const grossWin = wins.reduce(
    (s, t) => s + Math.max(0, t.outcome_pnl_pips || 0),
    0,
  );
  const grossLoss = losses.reduce(
    (s, t) => s + Math.abs(Math.min(0, t.outcome_pnl_pips || 0)),
    0,
  );

  const profitFactor =
    grossLoss === 0 ? (grossWin > 0 ? 999 : 0) : grossWin / grossLoss;
  const totalPips = closed.reduce((s, t) => s + (t.outcome_pnl_pips || 0), 0);
  const winRate = (wins.length / closed.length) * 100;

  // Max drawdown (sequential)
  let peak = 0,
    dd = 0,
    maxDD = 0,
    running = 0;
  for (const t of closed) {
    running += t.outcome_pnl_pips || 0;
    if (running > peak) peak = running;
    dd = peak - running;
    if (dd > maxDD) maxDD = dd;
  }
  const maxDDPct = peak > 0 ? (maxDD / Math.max(peak, 1)) * 100 : 0;

  // Simplified Sharpe (mean / stdev of returns)
  const pnls = closed.map((t) => t.outcome_pnl_pips || 0);
  const mean = totalPips / pnls.length;
  const variance =
    pnls.reduce((s, p) => s + Math.pow(p - mean, 2), 0) / pnls.length;
  const stdev = Math.sqrt(variance);
  const sharpe =
    stdev === 0 ? 0 : parseFloat(((mean / stdev) * Math.sqrt(252)).toFixed(2));

  return {
    trades: closed.length,
    wins: wins.length,
    losses: losses.length,
    winRate: parseFloat(winRate.toFixed(1)),
    profitFactor: parseFloat(profitFactor.toFixed(2)),
    totalPips: parseFloat(totalPips.toFixed(1)),
    grossWin: parseFloat(grossWin.toFixed(1)),
    grossLoss: parseFloat(grossLoss.toFixed(1)),
    maxDD: parseFloat(maxDD.toFixed(1)),
    maxDDPct: parseFloat(maxDDPct.toFixed(1)),
    sharpe,
  };
}

/**
 * Determine pass/fail for a window
 */
function passCheck(metrics, minTrades) {
  const effectiveMin = minTrades || PASS_CRITERIA.minTrades;
  const checks = {
    sufficientTrades: metrics.trades >= effectiveMin,
    profitFactor: metrics.profitFactor >= PASS_CRITERIA.minProfitFactor,
    drawdown: metrics.maxDDPct <= PASS_CRITERIA.maxDrawdownPct,
    winRate: metrics.winRate >= PASS_CRITERIA.minWinRate,
  };
  const pass = Object.values(checks).every(Boolean);
  return { pass, checks };
}

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const numWindows = Math.min(
      8,
      Math.max(2, parseInt(searchParams.get("windows") || "4")),
    );
    const minTrades = parseInt(searchParams.get("minTrades") || "5");

    // Fetch all closed trades ordered by time
    const allTrades = await sql`
      SELECT id, instrument, direction, outcome, outcome_pnl_pips,
             created_at, outcome_timestamp_utc, adx_value, atr_value,
             signal_status
      FROM audit_logs
      WHERE signal_status = 'ACTIVE'
        AND outcome != 'pending'
        AND outcome_pnl_pips IS NOT NULL
      ORDER BY created_at ASC
    `;

    if (allTrades.length < 4) {
      // Not enough real data — seed with backtest distribution from Alpha Rehabilitation
      const seedTrades = generateSeedTrades();
      return runWFA(seedTrades, numWindows, minTrades, true);
    }

    return runWFA(allTrades, numWindows, minTrades, false);
  } catch (err) {
    console.error("[WFA]", err);
    return Response.json({ error: err.message }, { status: 500 });
  }
}

/**
 * Generate seed trades from the Alpha Rehabilitation backtest
 * 17 trades: 9 wins (avg +5.46R @ 60p), 8 losses (avg -1R @ -60p)
 */
function generateSeedTrades() {
  const trades = [];
  const now = Date.now();
  const outcomes = [
    "tp2_hit",
    "tp2_hit",
    "tp2_hit",
    "sl_hit",
    "tp2_hit",
    "sl_hit",
    "tp2_hit",
    "sl_hit",
    "tp2_hit",
    "sl_hit",
    "tp2_hit",
    "sl_hit",
    "tp2_hit",
    "sl_hit",
    "tp2_hit",
    "sl_hit",
    "sl_hit",
  ];
  outcomes.forEach((outcome, i) => {
    const isWin = outcome === "tp2_hit";
    trades.push({
      id: `seed_${i}`,
      instrument: i % 2 === 0 ? "EURUSD" : "XAUUSD",
      direction: i % 3 === 0 ? "SHORT" : "LONG",
      outcome,
      outcome_pnl_pips: isWin ? 60 * 5.46 : -60,
      created_at: new Date(
        now - (17 - i) * 14 * 24 * 60 * 60 * 1000,
      ).toISOString(),
      adx_value: 18 + Math.random() * 10,
      atr_value: 0.0008 + Math.random() * 0.0003,
    });
  });
  return trades;
}

function runWFA(trades, numWindows, minTrades, isSeeded) {
  const n = trades.length;
  // Use 70% for in-sample, 30% for out-of-sample per window
  const windowSize = Math.floor(n / numWindows);
  const trainSize = Math.floor(windowSize * 0.7);
  const testSize = windowSize - trainSize;

  const windows = [];
  let allTestPassed = 0;

  for (let w = 0; w < numWindows; w++) {
    const start = w * windowSize;
    const trainEnd = start + trainSize;
    const testEnd = Math.min(start + windowSize, n);

    const trainData = trades.slice(start, trainEnd);
    const testData = trades.slice(trainEnd, testEnd);

    const trainMetrics = calcMetrics(trainData);
    const testMetrics = calcMetrics(testData);
    const { pass, checks } = passCheck(testMetrics, minTrades);

    if (pass) allTestPassed++;

    windows.push({
      window: w + 1,
      period: `W${w + 1}`,
      startIdx: start,
      endIdx: testEnd,
      startDate: trainData[0]?.created_at?.slice(0, 10) || `Day ${start}`,
      endDate:
        testData[testData.length - 1]?.created_at?.slice(0, 10) ||
        `Day ${testEnd}`,
      inSample: { ...trainMetrics, label: "Train" },
      outOfSample: { ...testMetrics, label: "Test" },
      pass,
      checks,
    });
  }

  // Aggregate full-dataset metrics
  const fullMetrics = calcMetrics(trades);
  const passRate = parseFloat(((allTestPassed / numWindows) * 100).toFixed(1));
  const overallPass = passRate >= 75; // 3 out of 4 windows must pass

  // Efficiency ratio (out-of-sample PF / in-sample PF)
  const avgInPF =
    windows.reduce((s, w) => s + w.inSample.profitFactor, 0) / windows.length;
  const avgOutPF =
    windows.reduce((s, w) => s + w.outOfSample.profitFactor, 0) /
    windows.length;
  const efficiency =
    avgInPF > 0 ? parseFloat(((avgOutPF / avgInPF) * 100).toFixed(1)) : 0;

  // Chart data: each window's in-sample vs out-of-sample PF
  const chartData = windows.map((w) => ({
    window: `W${w.window}`,
    inSamplePF: w.inSample.profitFactor,
    oofPF: w.outOfSample.profitFactor,
    passLine: PASS_CRITERIA.minProfitFactor,
  }));

  // Cumulative pips chart
  let cum = 0;
  const cumulativeChart = trades.map((t, i) => {
    cum += t.outcome_pnl_pips || 0;
    return { trade: i + 1, pips: parseFloat(cum.toFixed(1)) };
  });

  const verdict = overallPass ? "PASS" : passRate >= 50 ? "MARGINAL" : "FAIL";

  return Response.json({
    summary: {
      totalTrades: n,
      numWindows,
      windowsPassed: allTestPassed,
      passRate: `${passRate}%`,
      overallVerdict: verdict,
      efficiency: `${efficiency}%`,
      dataSource: isSeeded
        ? "backtest_seed (Alpha Rehabilitation — 17 trades)"
        : "live_audit_log",
    },
    criteria: PASS_CRITERIA,
    fullDataset: fullMetrics,
    windows,
    chartData,
    cumulativeChart,
    recommendation:
      verdict === "PASS"
        ? "✅ Strategy shows out-of-sample validity. Proceed to paper trading."
        : verdict === "MARGINAL"
          ? "⚠️ Mixed results. Run more trades before live capital."
          : "❌ Strategy fails out-of-sample. Do NOT go live. Review regime filters.",
  });
}
