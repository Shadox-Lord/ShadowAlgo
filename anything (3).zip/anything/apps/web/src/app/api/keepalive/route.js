/**
 * Keep-Alive Endpoint
 * Prevents Vercel serverless cold starts by responding to ping requests
 * Also validates core system health in one lightweight call
 * GET /api/keepalive
 *
 * How to use:
 * - Vercel Cron: set up a cron job in vercel.json to hit /api/keepalive every 14 minutes
 * - External: use UptimeRobot / BetterStack to ping this URL every 10-14 minutes (free tier)
 * - Self-ping: The dashboard pings this automatically every 14 minutes when open
 */

import sql from "@/app/api/utils/sql";

export async function GET() {
  const start = Date.now();

  let dbStatus = "ok";
  let systemState = null;
  let activeCount = 0;

  try {
    const [state] = await sql`SELECT * FROM system_state WHERE id = 1`;
    systemState = state;

    const [{ count }] = await sql`
      SELECT COUNT(*) as count FROM audit_logs
      WHERE outcome = 'pending' AND signal_status = 'ACTIVE'
    `;
    activeCount = parseInt(count || 0);
  } catch (err) {
    dbStatus = `error: ${err.message}`;
  }

  const latencyMs = Date.now() - start;

  return Response.json({
    status: "alive",
    timestamp: new Date().toISOString(),
    latencyMs,
    db: dbStatus,
    system: {
      paused: systemState?.is_paused ?? null,
      equity: systemState?.current_equity ?? null,
      activeTrades: activeCount,
    },
    // Vercel edge info
    region: process.env.VERCEL_REGION || "local",
    env: process.env.NEXT_PUBLIC_CREATE_ENV || "development",
    message: "🟢 KRONOS + SHADOW AI — System Operational",
  });
}

// Also accept HEAD requests (used by uptime monitors)
export async function HEAD() {
  return new Response(null, { status: 200 });
}
