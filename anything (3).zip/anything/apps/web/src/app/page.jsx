"use client";
import React, { useState, useEffect } from "react";
import {
  DashboardHeader,
  StatsGrid,
} from "@/components/Dashboard/DashboardHeader";
import { TabNavigation } from "@/components/Dashboard/TabNavigation";
import { SignalPanel } from "@/components/Dashboard/SignalPanel";
import { OverviewTab } from "@/components/Dashboard/OverviewTab";
import { SignalsTab } from "@/components/Dashboard/SignalsTab";
import { AuditLogTab } from "@/components/Dashboard/AuditLogTab";
import { RiskTab } from "@/components/Dashboard/RiskTab";
import { MonteCarloTab } from "@/components/Dashboard/MonteCarloTab";
import { CorrelationTab } from "@/components/Dashboard/CorrelationTab";
import { WFATab } from "@/components/Dashboard/WFATab";
import { NewsTab } from "@/components/Dashboard/NewsTab";
import { useTradingData } from "@/hooks/useTradingData";
import { calculateDerivedStats, getStatsCards } from "@/utils/trading-stats";

export default function TradingDashboard() {
  const [activeTab, setActiveTab] = useState("overview");
  const [selectedInstrument, setSelectedInstrument] = useState("EURUSD");
  const [selectedTimeframe, setSelectedTimeframe] = useState("H4");
  const [showSignalPanel, setShowSignalPanel] = useState(false);
  const [wfaWindows, setWfaWindows] = useState(4);

  const {
    logs,
    systemState,
    monteCarlo,
    mcFetching,
    refetchMC,
    correlation,
    corrFetching,
    refetchCorr,
    wfa,
    wfaFetching,
    refetchWFA,
    newsCalendar,
    refetchNews,
    togglePause,
    triggerSignal,
    closeTrade,
  } = useTradingData({ wfaWindows });

  // Keep-alive ping every 14 minutes (prevents Vercel cold starts)
  useEffect(() => {
    const ping = () => fetch("/api/keepalive").catch(() => {});
    ping();
    const interval = setInterval(ping, 14 * 60 * 1000);
    return () => clearInterval(interval);
  }, []);

  const derivedStats = calculateDerivedStats(systemState, logs);
  const stats = getStatsCards(derivedStats);

  const handleTogglePause = () => {
    togglePause.mutate(!systemState?.is_paused);
  };

  const handleTriggerSignal = () => {
    setShowSignalPanel(true);
  };

  const handleSignalSubmit = () => {
    triggerSignal.mutate(
      {
        instrument: selectedInstrument,
        timeframe: selectedTimeframe,
      },
      {
        onSuccess: () => setShowSignalPanel(false),
      },
    );
  };

  const handleCloseTrade = (params) => {
    closeTrade.mutate(params);
  };

  const signalError = triggerSignal.isError
    ? triggerSignal.error?.message || "Signal failed"
    : triggerSignal.data?.error || null;

  return (
    <div className="flex flex-col gap-8">
      <SignalPanel
        show={showSignalPanel}
        onClose={() => setShowSignalPanel(false)}
        selectedInstrument={selectedInstrument}
        setSelectedInstrument={setSelectedInstrument}
        selectedTimeframe={selectedTimeframe}
        setSelectedTimeframe={setSelectedTimeframe}
        onTrigger={handleSignalSubmit}
        isTriggering={triggerSignal.isPending}
        error={signalError}
      />

      <DashboardHeader
        systemState={systemState}
        onTogglePause={handleTogglePause}
        onTriggerSignal={handleTriggerSignal}
      />

      <StatsGrid stats={stats} />

      <TabNavigation activeTab={activeTab} onTabChange={setActiveTab} />

      <div className="min-h-[500px]">
        {activeTab === "overview" && (
          <OverviewTab
            closedTrades={derivedStats.closedTrades}
            winRate={derivedStats.winRate}
            maxDD={derivedStats.maxDD}
          />
        )}

        {activeTab === "signals" && (
          <SignalsTab
            activeTrades={derivedStats.activeTrades}
            onCloseTrade={handleCloseTrade}
          />
        )}

        {activeTab === "audit-log" && <AuditLogTab logs={logs} />}

        {activeTab === "risk" && <RiskTab />}

        {activeTab === "monte-carlo" && (
          <MonteCarloTab
            monteCarlo={monteCarlo}
            mcFetching={mcFetching}
            onRefetch={refetchMC}
          />
        )}

        {activeTab === "correlation" && (
          <CorrelationTab
            correlation={correlation}
            corrFetching={corrFetching}
            onRefetch={refetchCorr}
          />
        )}

        {activeTab === "wfa" && (
          <WFATab
            wfa={wfa}
            wfaFetching={wfaFetching}
            onRefetch={refetchWFA}
            wfaWindows={wfaWindows}
            setWfaWindows={setWfaWindows}
          />
        )}

        {activeTab === "news" && (
          <NewsTab newsCalendar={newsCalendar} onRefetch={refetchNews} />
        )}
      </div>
    </div>
  );
}
