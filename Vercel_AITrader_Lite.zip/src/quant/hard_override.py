import time

class HardQuantOverride:
    def __init__(self, min_confidence: int = 75, min_rr: float = 2.5, max_spread: float = 0.0002):
        self.min_confidence = min_confidence
        self.min_rr = min_rr
        self.max_spread = max_spread # 2 pips max spread

    def evaluate(self, bull_score: int, bear_score: int, smc_context: dict, current_spread: float, timestamp: float) -> dict:
        # 1. Stale Signal Check
        if time.time() - timestamp > 300: # 5 minutes
            return {"approved": False, "reason": "Signal is stale (> 5 mins)."}
            
        # 2. Spread Check
        if current_spread > self.max_spread:
            return {"approved": False, "reason": f"Spread too high ({current_spread} > {self.max_spread}). Liquidity gap risk."}

        # 3. Anti-Consensus Check
        if bull_score > 90 and bear_score > 90:
            return {"approved": False, "reason": "Anti-consensus trigger. Too obvious. Possible trap."}
            
        winning_bias = "BUY" if bull_score > bear_score else "SELL"
        confidence = max(bull_score, bear_score)
        
        # 4. Minimum Confidence
        if confidence < self.min_confidence:
            return {"approved": False, "reason": f"Low confidence ({confidence} < {self.min_confidence})"}
            
        # 5. SMC Alignment Check
        if winning_bias != smc_context.get("direction_bias"):
            return {"approved": False, "reason": "AI thesis opposes hard SMC structural reality."}
            
        return {
            "approved": True,
            "direction": winning_bias,
            "confidence": confidence,
            "risk_reward": self.min_rr,
            "entry": 1.0520,
            "stop_loss": 1.0500,
            "take_profit": 1.0570
        }
