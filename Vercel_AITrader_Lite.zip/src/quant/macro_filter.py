import json

class MacroRiskFilter:
    """Deterministic Macro Risk Gatekeeper. Replaces the LLM News Analyst."""
    def __init__(self):
        self.toxic_keywords = ["CPI", "FOMC", "NFP", "NON-FARM", "RATE DECISION", "POWELL", "LAGARDE"]

    def is_safe_to_trade(self, calendar_events: list[str]) -> dict:
        for event in calendar_events:
            event_upper = event.upper()
            if any(keyword in event_upper for keyword in self.toxic_keywords):
                return {
                    "safe": False, 
                    "reason": f"TOXIC MACRO DAY: Found red-folder event '{event}'."
                }
        return {"safe": True, "reason": "No high-impact macro events detected."}
