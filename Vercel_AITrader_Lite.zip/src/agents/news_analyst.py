from pydantic import BaseModel, Field
import json
import logging

class NewsMacroResponse(BaseModel):
    is_toxic_macro_day: bool = Field(description="True if major news (NFP, CPI, ECB) prevents safe trading.")
    macro_bias: str = Field(description="BULL, BEAR, or NEUTRAL.")
    reasoning: str = Field(description="One sentence justification.")

class NewsAnalyst:
    """Evaluates macro calendar risk."""
    def analyze(self, calendar_data: dict) -> dict:
        # Mocked LLM logic for serverless stability without keys in this demo
        has_nfp = "NFP" in str(calendar_data)
        return NewsMacroResponse(
            is_toxic_macro_day=has_nfp,
            macro_bias="NEUTRAL",
            reasoning="No high-impact data detected today." if not has_nfp else "NFP release today. TOXIC. DO NOT TRADE."
        ).model_dump()
