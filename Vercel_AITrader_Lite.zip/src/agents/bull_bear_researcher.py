from pydantic import BaseModel, Field

class ThesisResponse(BaseModel):
    score: int = Field(ge=0, le=100, description="Confidence score from 0-100.")
    arguments: list[str] = Field(description="Top 3 tactical arguments.")

class Researcher:
    def __init__(self, role: str):
        self.role = role
        
    def analyze(self, market_data: dict, smc_context: dict) -> dict:
        # Mocked LLM structured response
        return ThesisResponse(
            score=80 if self.role == "BULL" else 30,
            arguments=[f"{self.role} logic 1", f"{self.role} logic 2"]
        ).model_dump()
