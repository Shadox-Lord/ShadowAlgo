import os
import aiohttp

class TelegramAlert:
    def __init__(self):
        self.bot_token = os.environ.get("TELEGRAM_BOT_TOKEN")
        self.chat_id = os.environ.get("TELEGRAM_CHAT_ID")
        
    async def send_alert(self, message: str):
        if not self.bot_token or not self.chat_id:
            print("Telegram Alert:", message)
            return
        url = f"https://api.telegram.org/bot{self.bot_token}/sendMessage"
        payload = {"chat_id": self.chat_id, "text": message, "parse_mode": "Markdown"}
        async with aiohttp.ClientSession() as session:
            await session.post(url, json=payload)
