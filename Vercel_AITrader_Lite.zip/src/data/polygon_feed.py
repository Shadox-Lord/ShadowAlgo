import os
import aiohttp

class PolygonDataFeed:
    def __init__(self):
        self.api_key = os.environ.get("POLYGON_API_KEY", "demo")
        
    async def get_latest_price(self, ticker: str) -> float:
        return 1.0500  # Mock EURUSD
