import json
import logging
from http.server import BaseHTTPRequestHandler
import sys
import os
import time

# Mock adding src to path for Vercel execution
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from src.data.polygon_feed import PolygonDataFeed
from src.quant.smc_validator import SMCStructuralValidator
from src.quant.macro_filter import MacroRiskFilter
from src.agents.bull_bear_researcher import Researcher
from src.quant.hard_override import HardQuantOverride
from src.utils.telegram import TelegramAlert
import asyncio

logger = logging.getLogger("CronScan")

class handler(BaseHTTPRequestHandler):
    def do_GET(self):
        try:
            # Wrap entire pipeline in a 9-second timeout to survive Vercel's 10s Free Tier limit
            result = asyncio.run(asyncio.wait_for(self.execute_pipeline(), timeout=9.0))
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps(result).encode('utf-8'))
        except asyncio.TimeoutError:
            self.send_response(504)
            self.end_headers()
            self.wfile.write(json.dumps({"status": "NO-TRADE", "reason": "Vercel execution timeout limit exceeded. Aborting."}).encode('utf-8'))
        except Exception as e:
            self.send_response(500)
            self.end_headers()
            self.wfile.write(json.dumps({"error": str(e)}).encode('utf-8'))

    async def execute_pipeline(self):
        feed = PolygonDataFeed()
        smc = SMCStructuralValidator()
        macro_filter = MacroRiskFilter()
        bull = Researcher("BULL")
        bear = Researcher("BEAR")
        quant = HardQuantOverride()
        tg = TelegramAlert()
        
        # 1. Fetch Data
        price = await feed.get_latest_price("EURUSD")
        spread = 0.0001 # Mock 1 pip spread
        
        # 2. Macro Risk (DETERMINISTIC)
        macro_status = macro_filter.is_safe_to_trade(["EU Retail Sales", "US CPI Release"])
        if not macro_status["safe"]:
            return {"status": "NO-TRADE", "reason": macro_status["reason"]}

        # 3. SMC Validation (DETERMINISTIC)
        smc_ctx = smc.validate_amd_setup("EURUSD", {"consolidation": True, "liquidity_sweep": "DOWN"})
        if not smc_ctx["valid"]:
            return {"status": "NO-TRADE", "reason": "No valid AMD liquidity sweep structure."}
            
        # 4. LLM Debate (AI)
        bull_thesis = bull.analyze({"price": price}, smc_ctx)
        bear_thesis = bear.analyze({"price": price}, smc_ctx)
        
        # 5. Quant Override (DETERMINISTIC GATEKEEPER)
        decision = quant.evaluate(
            bull_score=bull_thesis["score"], 
            bear_score=bear_thesis["score"], 
            smc_context=smc_ctx,
            current_spread=spread,
            timestamp=time.time()
        )
        
        if not decision["approved"]:
            return {"status": "NO-TRADE", "reason": decision["reason"]}
            
        # 6. Output Generation
        alert_msg = f"""🚨 **EURUSD TACTICAL ALERT** 🚨
*Direction*: {decision['direction']}
*Entry*: {decision['entry']}
*SL*: {decision['stop_loss']}
*TP*: {decision['take_profit']}
*RR*: 1:{decision['risk_reward']}
*Confidence*: {decision['confidence']}%

*Macro Checks*: PASSED (No Toxic Events)
*Spread*: PASSED ({spread*10000} pips)

_Execute manually on MT5. 0.3% Risk only._
"""
        await tg.send_alert(alert_msg)
        return {"status": "ALERT_SENT", "data": decision}
