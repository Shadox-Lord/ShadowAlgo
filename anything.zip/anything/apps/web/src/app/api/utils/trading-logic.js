import sql from "@/app/api/utils/sql";

// ═══════════════════════════════════════════════════════════════
// SHADOW AUDITOR CONFIG — ShadowAlgo v3.0 (Alpha Rehabilitation)
// ═══════════════════════════════════════════════════════════════
export const CONFIG = {
  MAX_DAILY_LOSS_PERCENT: 4.5,
  MAX_TRADE_RISK_PERCENT: 0.3, // 0.3% per trade (prop firm standard)
  MIN_CONFIDENCE_SCORE: 70,
  MIN_RR_RATIO: 2.0,
  MIN_ADX: 14, // Phase 1 Clean Room: relaxed from 20 for freq
  MIN_ATR_PERCENTILE: 30,
  BREAKEVEN_BUFFER_PIPS: 1.5, // Prevent spread/commission bleed
  PARTIAL_TP_CLOSE_PERCENT: 50, // Close 50% at 1:2 RR
  TIME_DECAY_HOURS: 18, // Force close after 18 hours
  MAX_CONSECUTIVE_LOSSES: 3,
  MAX_WEEKLY_LOSS_PERCENT: 8,
  RATE_LIMIT_MAX_REQUESTS: 10,
};

export const SUPPORTED_ASSETS = ["EURUSD", "XAUUSD"];

// ═══════════════════════════════════════════════════════════════
// FEW-SHOT AUTOPSY INJECTION — Patch 3 (Compressed Failure Sigs)
// ═══════════════════════════════════════════════════════════════
export const FAILURE_SIGNATURES = `
CRITICAL FAILURE PATTERNS TO AVOID:
1. LOW_VOLATILITY_CHOP: ADX < 20 + tight range consolidation = 73% loss rate. DO NOT TRADE.
2. PRE_FOMC_DRIFT: 2 hours before FOMC + no clear structure = 68% loss rate. DO NOT TRADE.
3. POST_NFP_EXHAUSTION: After NFP spike + counter-trend entry = 81% loss rate. DO NOT TRADE.
4. SUMMER_LIQUIDITY_CRUNCH: July-August + low volume + false breakout = 65% loss rate. DO NOT TRADE.
5. LIQUIDITY_SWEEP_WITHOUT_BOS: Sweep without confirmed Break of Structure = 59% loss rate. DO NOT TRADE.

MANDATORY STRUCTURAL REQUIREMENTS:
- Must identify clear liquidity sweep (stop hunt beyond recent high/low)
- Must confirm Break of Structure (BOS) in opposite direction AFTER sweep
- Must have Fair Value Gap (FVG) or Order Block for entry
- If any requirement missing → structure_valid: false → NO_TRADE
`;

// ═══════════════════════════════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════════════════════════════

/**
 * Escapes characters for Telegram MarkdownV2
 */
export function escapeMarkdownV2(text) {
  if (typeof text !== "string") return String(text ?? "");
  return text.replace(/([_\*\[\]()~`>#\+\-=|{}.!])/g, "\\$1");
}

/**
 * Returns pip multiplier for an instrument
 * EURUSD = 0.0001, XAUUSD = 0.1, JPY pairs = 0.01
 */
export function getPipMultiplier(symbol) {
  if (!symbol) return 0.0001;
  if (symbol.includes("XAU") || symbol.includes("GOLD")) return 0.1;
  if (symbol.includes("JPY")) return 0.01;
  return 0.0001;
}

/**
 * Convert price distance to pips
 */
export function toPips(priceDist, symbol) {
  return Math.abs(priceDist) / getPipMultiplier(symbol);
}

/**
 * Real ADX(14) + ATR(14) calculation from OHLCV candle array
 * Each candle: { open, high, low, close, volume }
 */
export function calculateRegimeIndicators(candles) {
  if (!candles || candles.length < 30)
    return { adx: 0, atr: 0, atrPercentile: 0 };

  const period = 14;
  let trSum = 0,
    plusDMSum = 0,
    minusDMSum = 0;

  for (let i = candles.length - period; i < candles.length; i++) {
    const c = candles[i];
    const pc = candles[i - 1];
    const tr = Math.max(
      c.high - c.low,
      Math.abs(c.high - pc.close),
      Math.abs(c.low - pc.close),
    );
    trSum += tr;
    const plusDM =
      c.high - pc.high > pc.low - c.low ? Math.max(c.high - pc.high, 0) : 0;
    const minusDM =
      pc.low - c.low > c.high - pc.high ? Math.max(pc.low - c.low, 0) : 0;
    plusDMSum += plusDM;
    minusDMSum += minusDM;
  }

  const atr = trSum / period;
  const plusDI = (plusDMSum / (trSum + 1e-9)) * 100;
  const minusDI = (minusDMSum / (trSum + 1e-9)) * 100;
  const dx = (Math.abs(plusDI - minusDI) / (plusDI + minusDI + 1e-9)) * 100;
  const adx = dx; // single-period approximation

  // ATR percentile across last 50 candles
  const atrValues = [];
  for (
    let i = Math.max(1, candles.length - 50);
    i < candles.length - period;
    i++
  ) {
    let trMax = 0;
    for (let j = 0; j < period && i + j < candles.length; j++) {
      const c = candles[i + j];
      const pc = candles[i + j - 1];
      if (!c || !pc) continue;
      trMax += Math.max(
        c.high - c.low,
        Math.abs(c.high - pc.close),
        Math.abs(c.low - pc.close),
      );
    }
    atrValues.push(trMax / period);
  }
  atrValues.sort((a, b) => a - b);
  const pctIdx = Math.floor(
    atrValues.length * (CONFIG.MIN_ATR_PERCENTILE / 100),
  );
  const atrPercentile = atrValues[pctIdx] || 0;

  return { adx, atr, atrPercentile };
}

/**
 * Regime gate check (Patch 1 — Hard Block)
 */
export function checkMarketRegime(candles) {
  const { adx, atr, atrPercentile } = calculateRegimeIndicators(candles);
  const isTrending = adx >= CONFIG.MIN_ADX;
  const isVolatile = atr >= atrPercentile;
  return {
    isTradeable: isTrending && isVolatile,
    adx,
    atr,
    atrPercentile,
    reason: !isTrending
      ? "ADX too low (choppy market)"
      : !isVolatile
        ? "ATR below percentile (low volatility)"
        : "Market regime OK",
  };
}

/**
 * Kill-switch check: halt if consecutive losses hit limit (Patch 4)
 */
export async function checkKillSwitches() {
  try {
    const rows = await sql`
      SELECT outcome FROM audit_logs
      WHERE outcome IN ('sl_hit', 'kill_switch', 'tp1_hit', 'tp2_hit')
      ORDER BY outcome_timestamp_utc DESC
      LIMIT ${CONFIG.MAX_CONSECUTIVE_LOSSES}
    `;
    if (rows.length >= CONFIG.MAX_CONSECUTIVE_LOSSES) {
      const allLosses = rows.every(
        (r) => r.outcome === "sl_hit" || r.outcome === "kill_switch",
      );
      if (allLosses) return { blocked: true, reason: "MAX_CONSECUTIVE_LOSSES" };
    }
    return { blocked: false };
  } catch {
    return { blocked: false };
  }
}

// ═══════════════════════════════════════════════════════════════
// LAYER 1 — KRONOS FORECASTER (Qwen-Plus via DashScope)
// ═══════════════════════════════════════════════════════════════
export async function runKronosForecaster(ohlcv, timeframe, candles) {
  const instrument = ohlcv.instrument || "EURUSD";
  const currentPrice = ohlcv.close;
  const checkpoint = "qwen-plus@kronos-v3.0";

  // Summarise candle stats for the LLM context
  const recent = candles ? candles.slice(-20) : [];
  const highs = recent.map((c) => c.high);
  const lows = recent.map((c) => c.low);
  const recentHigh = highs.length ? Math.max(...highs) : currentPrice * 1.01;
  const recentLow = lows.length ? Math.min(...lows) : currentPrice * 0.99;
  const range = recentHigh - recentLow;

  // --- Try real Qwen-Plus LLM ---
  const apiKey = process.env.QWEN_API_KEY;
  if (apiKey) {
    try {
      const baseURL =
        process.env.QWEN_BASE_URL ||
        "https://dashscope.aliyuncs.com/compatible-mode/v1";
      const prompt = `You are Kronos, a quantitative trading forecaster specialising in Smart Money Concepts (SMC) for FX/Gold.

${FAILURE_SIGNATURES}

Analyse the following ${timeframe} market data for ${instrument}:
- Current Price: ${currentPrice}
- Recent 20-candle High: ${recentHigh.toFixed(5)}
- Recent 20-candle Low: ${recentLow.toFixed(5)}
- Range: ${range.toFixed(5)}
- Candles available: ${candles?.length || 0}

Identify:
1. Liquidity sweep (stop hunt)
2. Break of Structure (BOS) direction
3. Fair Value Gap (FVG) or Order Block presence
4. Forecast direction (LONG/SHORT/NEUTRAL) and uncertainty (0-1)

Return ONLY valid JSON (no markdown):
{"forecast_direction":"LONG|SHORT|NEUTRAL","forecast_price_target":float,"uncertainty_score":float,"structure_valid":bool,"smc_context":"brief description","raw_return_estimate":float}`;

      const res = await fetch(`${baseURL}/chat/completions`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "qwen-plus",
          messages: [{ role: "user", content: prompt }],
          temperature: 0.7,
          max_tokens: 300,
          response_format: { type: "json_object" },
        }),
      });

      if (res.ok) {
        const data = await res.json();
        const parsed = JSON.parse(data.choices?.[0]?.message?.content || "{}");
        if (parsed.forecast_direction) {
          return {
            instrument,
            timeframe,
            model_checkpoint: checkpoint,
            forecast_direction: parsed.forecast_direction,
            forecast_price_target: parsed.forecast_price_target || currentPrice,
            forecast_horizon_candles: 18,
            uncertainty_score: Math.min(
              1,
              Math.max(0, parsed.uncertainty_score ?? 0.4),
            ),
            raw_return_estimate: parsed.raw_return_estimate || 0,
            smc_context: parsed.smc_context || "",
            structure_valid: parsed.structure_valid !== false,
            candles_used: candles?.length || 0,
            volume_available: true,
            timestamp_utc: new Date().toISOString(),
          };
        }
      }
    } catch (err) {
      console.error(
        "[Kronos] Qwen LLM error, falling back to simulation:",
        err.message,
      );
    }
  }

  // --- Fallback: deterministic simulation ---
  const pipMult = getPipMultiplier(instrument);
  const rangePips = range / pipMult;
  const uncertaintyScore = rangePips < 20 ? 0.72 : Math.random() * 0.5 + 0.1;
  const direction =
    uncertaintyScore > 0.65
      ? "NEUTRAL"
      : Math.random() > 0.5
        ? "LONG"
        : "SHORT";

  return {
    instrument,
    timeframe,
    model_checkpoint: checkpoint + "-sim",
    forecast_direction: direction,
    forecast_price_target:
      currentPrice *
      (direction === "LONG" ? 1.002 : direction === "SHORT" ? 0.998 : 1),
    forecast_horizon_candles: 18,
    uncertainty_score: uncertaintyScore,
    raw_return_estimate: direction === "NEUTRAL" ? 0 : 1.8,
    smc_context: "Simulated — set QWEN_API_KEY for live SMC analysis",
    structure_valid: direction !== "NEUTRAL",
    candles_used: candles?.length || 0,
    volume_available: false,
    timestamp_utc: new Date().toISOString(),
  };
}

// ═══════════════════════════════════════════════════════════════
// LAYER 2 — SHADOW AUDITOR (Regime + Risk Architecture)
// ═══════════════════════════════════════════════════════════════
export async function runShadowAuditor(
  l1Result,
  ohlcv,
  candles,
  accountBalance = 100000,
) {
  const instrument = l1Result.instrument;
  const pipMult = getPipMultiplier(instrument);

  // — STEP 2A: REGIME GATE (hard block) —
  const regime = checkMarketRegime(candles);
  const blockReasons = [];

  if (regime.adx < CONFIG.MIN_ADX) blockReasons.push("LOW_ADX");
  if (!regime.isVolatile) blockReasons.push("LOW_ATR");
  if (l1Result.uncertainty_score > 0.65) blockReasons.push("HIGH_UNCERTAINTY");
  if (!l1Result.structure_valid) blockReasons.push("NO_SMC_STRUCTURE");
  if (l1Result.forecast_direction === "NEUTRAL")
    blockReasons.push("NEUTRAL_FORECAST");

  if (blockReasons.length > 0) {
    return {
      signal_status: "BLOCKED",
      block_reason: blockReasons,
      instrument,
      timeframe: l1Result.timeframe,
      adx_value: regime.adx,
      atr_value: regime.atr,
      uncertainty_score: l1Result.uncertainty_score,
      smc_context: l1Result.smc_context || "",
      model_checkpoint: l1Result.model_checkpoint,
      timestamp_utc: new Date().toISOString(),
    };
  }

  // — STEP 2B: HARDENING —
  const promptHash =
    "sha256_" +
    Buffer.from(
      `${instrument}${l1Result.model_checkpoint}${l1Result.timestamp_utc}`,
    )
      .toString("base64")
      .substring(0, 12);

  // — STEP 2C: RISK ARCHITECTURE —
  const entry = ohlcv.close;
  const isLong = l1Result.forecast_direction === "LONG";

  // SL = Entry ± (1.5 × ATR)
  const sl = isLong ? entry - 1.5 * regime.atr : entry + 1.5 * regime.atr;

  const riskPips = toPips(Math.abs(entry - sl), instrument);

  // TP1 = 1:1 RR, TP2 = 2:1 RR
  const tp1 = isLong ? entry + (entry - sl) : entry - (sl - entry);
  const tp2 = isLong ? entry + 2 * (entry - sl) : entry - 2 * (sl - entry);

  // Breakeven level with buffer (Patch 2 — Asymmetric Exit)
  const breakevenBuffer = CONFIG.BREAKEVEN_BUFFER_PIPS * pipMult;
  const breakevenLevel = isLong
    ? entry + breakevenBuffer
    : entry - breakevenBuffer;

  // Lot size: (equity × risk%) / (riskPips × pip value)
  // Pip value ≈ $10 for standard lot on EURUSD, $1 for XAUUSD/10
  const pipValue = instrument.includes("XAU") ? 1.0 : 10.0;
  const riskAmount = accountBalance * (CONFIG.MAX_TRADE_RISK_PERCENT / 100);
  const lotSize = parseFloat((riskAmount / (riskPips * pipValue)).toFixed(2));
  const killTime = new Date(
    Date.now() + CONFIG.TIME_DECAY_HOURS * 60 * 60 * 1000,
  ).toISOString();

  return {
    signal_status: "ACTIVE",
    block_reason: [],
    instrument,
    timeframe: l1Result.timeframe,
    direction: l1Result.forecast_direction,
    entry_price: parseFloat(entry.toFixed(instrument.includes("XAU") ? 2 : 5)),
    stop_loss: parseFloat(sl.toFixed(instrument.includes("XAU") ? 2 : 5)),
    take_profit_1: parseFloat(tp1.toFixed(instrument.includes("XAU") ? 2 : 5)),
    take_profit_2: parseFloat(tp2.toFixed(instrument.includes("XAU") ? 2 : 5)),
    breakeven_level: parseFloat(
      breakevenLevel.toFixed(instrument.includes("XAU") ? 2 : 5),
    ),
    lot_size: Math.max(0.01, lotSize),
    risk_percent: CONFIG.MAX_TRADE_RISK_PERCENT,
    rr_ratio: 2.0,
    adx_value: regime.adx,
    atr_value: regime.atr,
    atr_pips: parseFloat(toPips(regime.atr, instrument).toFixed(1)),
    uncertainty_score: l1Result.uncertainty_score,
    smc_context: l1Result.smc_context || "",
    direction_conflict: false,
    prompt_hash: promptHash,
    time_kill_utc: killTime,
    model_checkpoint: l1Result.model_checkpoint,
    timestamp_utc: new Date().toISOString(),
  };
}

// ═══════════════════════════════════════════════════════════════
// LAYER 3 — TELEGRAM DISPATCHER (MarkdownV2)
// ═══════════════════════════════════════════════════════════════
export async function dispatchTelegramSignal(signal) {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;

  if (!token || !chatId) {
    console.warn("[Telegram] Bot token or chat ID not set — skipping dispatch");
    return null;
  }

  const e = escapeMarkdownV2;
  let message = "";

  if (signal.signal_status === "ACTIVE") {
    const pipMult = getPipMultiplier(signal.instrument);
    const slPips = toPips(
      signal.entry_price - signal.stop_loss,
      signal.instrument,
    ).toFixed(1);
    const tp1Pips = toPips(
      signal.take_profit_1 - signal.entry_price,
      signal.instrument,
    ).toFixed(1);
    const tp2Pips = toPips(
      signal.take_profit_2 - signal.entry_price,
      signal.instrument,
    ).toFixed(1);
    const bePips = toPips(
      signal.breakeven_level - signal.entry_price,
      signal.instrument,
    ).toFixed(1);

    message = `🟢 *NEW SIGNAL — KRONOS \\+ SHADOW AUDITOR v3\\.0*
📌 ${e(signal.instrument)} | 📐 ${e(signal.timeframe || "H4")} | 📈 *${e(signal.direction)}*
━━━━━━━━━━━━━━━━━━━
💰 Entry: \`${e(String(signal.entry_price))}\`
🛑 SL: \`${e(String(signal.stop_loss))}\` \\(${e(slPips)}p\\)
🎯 TP1: \`${e(String(signal.take_profit_1))}\` \\(\\+${e(tp1Pips)}p \\| 1:1\\)
🎯 TP2: \`${e(String(signal.take_profit_2))}\` \\(\\+${e(tp2Pips)}p \\| 2:1\\)
🔒 BE: \`${e(String(signal.breakeven_level))}\` \\(\\+${e(bePips)}p buffer\\)
━━━━━━━━━━━━━━━━━━━
📦 Lot: ${e(String(signal.lot_size))} | ⚖️ Risk: ${e(String(signal.risk_percent))}\\%
📊 ADX: ${e(signal.adx_value.toFixed(1))}✅ | 📊 ATR: ${e(String(signal.atr_pips))}p✅
🎲 Unc: ${e(signal.uncertainty_score.toFixed(2))}✅
🧠 SMC: _${e(signal.smc_context || "N/A")}_
━━━━━━━━━━━━━━━━━━━
⏱ Kill: ${e(signal.time_kill_utc)}
🔐 Hash: \`${e(signal.prompt_hash)}\`
🤖 ${e(signal.model_checkpoint)} | ⏰ ${e(signal.timestamp_utc)}
⚠️ _Risk management rules apply\\. Not financial advice\\._`;
  } else {
    message = `🔴 *SIGNAL BLOCKED — REGIME GATE*
📌 ${e(signal.instrument)} | 📐 ${e(signal.timeframe || "H4")}
🚫 Reason: *${e(signal.block_reason.join(", "))}*
📊 ADX: ${e(signal.adx_value?.toFixed(1) || "0")} | ATR: ${e(signal.atr_value?.toFixed(5) || "0")} | Unc: ${e(signal.uncertainty_score?.toFixed(2) || "0")}
🧠 SMC: _${e(signal.smc_context || "N/A")}_
❌ No trade\\. Wait for regime confirmation\\.
⏰ ${e(signal.timestamp_utc)}`;
  }

  // Retry logic: 3× exponential backoff
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      const res = await fetch(
        `https://api.telegram.org/bot${token}/sendMessage`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            chat_id: chatId,
            text: message,
            parse_mode: "MarkdownV2",
          }),
        },
      );
      const data = await res.json();
      if (data.ok) return data.result?.message_id;
      console.error("[Telegram] API error:", data.description);
    } catch (err) {
      console.error(`[Telegram] Attempt ${attempt + 1} failed:`, err.message);
      if (attempt < 2)
        await new Promise((r) => setTimeout(r, 1000 * Math.pow(2, attempt)));
    }
  }
  return null;
}
