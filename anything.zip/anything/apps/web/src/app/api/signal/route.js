import sql from "@/app/api/utils/sql";
import {
  runKronosForecaster,
  runShadowAuditor,
  dispatchTelegramSignal,
  checkKillSwitches,
  SUPPORTED_ASSETS,
  CONFIG,
} from "@/app/api/utils/trading-logic";

// Generate realistic synthetic OHLCV candles for a given symbol
function generateOHLCV(symbol, numCandles = 100) {
  // Base prices
  const basePrice = symbol === "XAUUSD" ? 2320.0 : 1.0845;
  const volatility = symbol === "XAUUSD" ? 8.0 : 0.0008;
  const candles = [];
  let price = basePrice;

  for (let i = 0; i < numCandles; i++) {
    const move = (Math.random() - 0.5) * 2 * volatility;
    const open = price;
    const close = price + move;
    const high = Math.max(open, close) + Math.random() * volatility * 0.5;
    const low = Math.min(open, close) - Math.random() * volatility * 0.5;
    candles.push({
      open,
      high,
      low,
      close,
      volume: 1000 + Math.random() * 5000,
    });
    price = close;
  }
  return { candles, currentPrice: price };
}

export async function POST(request) {
  try {
    const body = await request.json();
    const { instrument: rawInstrument, timeframe: rawTimeframe } = body;

    // Normalise inputs
    const instrument = (rawInstrument || "EURUSD")
      .toUpperCase()
      .replace("/", "");
    const timeframe = rawTimeframe || "H4";

    // Validate asset
    if (!SUPPORTED_ASSETS.includes(instrument)) {
      return Response.json(
        {
          error: `Unsupported instrument. Use: ${SUPPORTED_ASSETS.join(", ")}`,
        },
        { status: 400 },
      );
    }

    // 0. System state — pause check
    const [systemState] = await sql`SELECT * FROM system_state WHERE id = 1`;
    if (systemState?.is_paused) {
      return Response.json(
        { error: "System is paused. Use /resume to re-activate." },
        { status: 403 },
      );
    }

    // 0b. Daily drawdown check (Prop firm kill-switch)
    const currentEquity = systemState?.current_equity || 100000;
    const dailyStartEquity = systemState?.daily_start_equity || 100000;
    const dailyDD =
      ((dailyStartEquity - currentEquity) / dailyStartEquity) * 100;
    if (dailyDD >= CONFIG.MAX_DAILY_LOSS_PERCENT) {
      return Response.json(
        {
          error: `Daily drawdown limit hit (${dailyDD.toFixed(2)}% ≥ ${CONFIG.MAX_DAILY_LOSS_PERCENT}%). Trading halted.`,
        },
        { status: 403 },
      );
    }

    // 0c. Consecutive loss kill-switch check (Patch 4)
    const killSwitch = await checkKillSwitches();
    if (killSwitch.blocked) {
      return Response.json(
        {
          error: `Kill-switch triggered: ${killSwitch.reason}. Reset required.`,
        },
        { status: 403 },
      );
    }

    // 1. Generate OHLCV (synthetic — replace with live broker API in production)
    const { candles, currentPrice } = generateOHLCV(instrument, 100);
    const ohlcv = { instrument, close: currentPrice };

    // 2. LAYER 1: KRONOS FORECASTER
    const l1Result = await runKronosForecaster(ohlcv, timeframe, candles);

    // 3. LAYER 2: SHADOW AUDITOR
    const l2Result = await runShadowAuditor(
      l1Result,
      ohlcv,
      candles,
      currentEquity,
    );

    // 4. Telegram dispatch
    let telegramMessageId = null;
    if (l2Result.signal_status !== "FALLBACK_FAILED") {
      telegramMessageId = await dispatchTelegramSignal(l2Result);
    }

    // 5. Append-only audit log
    const [log] = await sql`
      INSERT INTO audit_logs (
        instrument, timeframe, direction, entry_price, stop_loss,
        take_profit_1, take_profit_2, lot_size, risk_percent,
        adx_value, atr_value, uncertainty_score, signal_status,
        block_reason, prompt_hash, model_checkpoint, time_kill_utc,
        telegram_message_id, smc_context, breakeven_level, atr_pips
      ) VALUES (
        ${l2Result.instrument},
        ${timeframe},
        ${l2Result.direction || null},
        ${l2Result.entry_price || null},
        ${l2Result.stop_loss || null},
        ${l2Result.take_profit_1 || null},
        ${l2Result.take_profit_2 || null},
        ${l2Result.lot_size || null},
        ${l2Result.risk_percent || CONFIG.MAX_TRADE_RISK_PERCENT},
        ${l2Result.adx_value},
        ${l2Result.atr_value},
        ${l2Result.uncertainty_score},
        ${l2Result.signal_status},
        ${l2Result.block_reason},
        ${l2Result.prompt_hash || null},
        ${l2Result.model_checkpoint || null},
        ${l2Result.time_kill_utc || null},
        ${telegramMessageId || null},
        ${l2Result.smc_context || null},
        ${l2Result.breakeven_level || null},
        ${l2Result.atr_pips || null}
      ) RETURNING *
    `;

    return Response.json({
      layer2: l2Result,
      log_id: log.id,
      telegram_message_id: telegramMessageId,
    });
  } catch (error) {
    console.error("[Signal] Generation failed:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}
