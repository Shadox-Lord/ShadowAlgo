"use client";
import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Activity,
  Shield,
  History,
  Settings,
  Play,
  Pause,
  RefreshCw,
  Terminal,
  ArrowUpRight,
  ArrowDownRight,
  Clock,
  Fingerprint,
  CheckCircle2,
  XCircle,
  Brain,
  AlertTriangle,
  TrendingUp,
  TrendingDown,
} from "lucide-react";
import { format } from "date-fns";
import {
  Card,
  MetaPill,
  ActionPill,
  StatusPill,
  CircularRing,
} from "@/components/ui";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
} from "recharts";

const INSTRUMENTS = ["EURUSD", "XAUUSD"];
const TIMEFRAMES = ["H1", "H4"];

const FAILURE_PATTERNS = [
  {
    id: 1,
    name: "LOW_VOLATILITY_CHOP",
    risk: "73%",
    color: "#EF4444",
    desc: "ADX < 20 + tight range consolidation",
  },
  {
    id: 2,
    name: "PRE_FOMC_DRIFT",
    risk: "68%",
    color: "#F97316",
    desc: "2h before FOMC + no clear structure",
  },
  {
    id: 3,
    name: "POST_NFP_EXHAUSTION",
    risk: "81%",
    color: "#EF4444",
    desc: "After NFP spike + counter-trend entry",
  },
  {
    id: 4,
    name: "SUMMER_LIQUIDITY_CRUNCH",
    risk: "65%",
    color: "#F97316",
    desc: "July-Aug + low volume + false breakout",
  },
  {
    id: 5,
    name: "LIQUIDITY_SWEEP_WITHOUT_BOS",
    risk: "59%",
    color: "#EAB308",
    desc: "Sweep without confirmed BOS",
  },
];

export default function TradingDashboard() {
  const [activeTab, setActiveTab] = useState("overview");
  const [selectedInstrument, setSelectedInstrument] = useState("EURUSD");
  const [selectedTimeframe, setSelectedTimeframe] = useState("H4");
  const [showSignalPanel, setShowSignalPanel] = useState(false);
  const queryClient = useQueryClient();

  // Queries
  const { data: logs = [], isLoading: logsLoading } = useQuery({
    queryKey: ["audit-logs"],
    queryFn: () => fetch("/api/audit-logs").then((r) => r.json()),
    refetchInterval: 10000,
  });

  const { data: systemState } = useQuery({
    queryKey: ["system-state"],
    queryFn: () => fetch("/api/system/state").then((r) => r.json()),
    refetchInterval: 15000,
  });

  // Mutations
  const togglePause = useMutation({
    mutationFn: (isPaused) =>
      fetch("/api/system/state", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ is_paused: isPaused }),
      }).then((r) => r.json()),
    onSuccess: () =>
      queryClient.invalidateQueries({ queryKey: ["system-state"] }),
  });

  const triggerSignal = useMutation({
    mutationFn: (params) =>
      fetch("/api/signal", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(params),
      }).then((r) => r.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["audit-logs"] });
      setShowSignalPanel(false);
    },
  });

  const closeTrade = useMutation({
    mutationFn: ({ id, outcome, pips }) =>
      fetch("/api/audit-logs", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, outcome, outcome_pnl_pips: pips }),
      }).then((r) => r.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["audit-logs"] });
      queryClient.invalidateQueries({ queryKey: ["system-state"] });
    },
  });

  // Derived stats
  const equity = systemState?.current_equity || 100000;
  const dailyStartEq = systemState?.daily_start_equity || 100000;
  const dailyDD = (((dailyStartEq - equity) / dailyStartEq) * 100).toFixed(2);
  const activeTrades = logs.filter(
    (l) => l.outcome === "pending" && l.signal_status === "ACTIVE",
  );
  const closedTrades = logs.filter((l) => l.outcome !== "pending");
  const wins = closedTrades.filter(
    (l) => l.outcome === "tp1_hit" || l.outcome === "tp2_hit",
  ).length;
  const winRate = closedTrades.length
    ? Math.round((wins / closedTrades.length) * 100)
    : 0;
  const totalPips = closedTrades.reduce(
    (s, l) => s + (l.outcome_pnl_pips || 0),
    0,
  );
  const maxDD = Math.max(0, parseFloat(dailyDD));

  const stats = [
    {
      label: "Current Equity",
      value: `$${equity.toLocaleString()}`,
      trend: `Daily DD: ${dailyDD}%`,
      up: parseFloat(dailyDD) < 2,
    },
    {
      label: "Active Trades",
      value: activeTrades.length,
      trend: "Live positions",
      up: true,
    },
    {
      label: "Total P&L",
      value: `${totalPips > 0 ? "+" : ""}${totalPips.toFixed(1)}p`,
      trend: `${closedTrades.length} closed`,
      up: totalPips >= 0,
    },
  ];

  return (
    <div className="flex flex-col gap-8">
      {/* Signal Panel Modal */}
      {showSignalPanel && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-[#E5E7EB] shadow-2xl w-full max-w-sm p-6 flex flex-col gap-5">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-[#111827]">
                Trigger Signal
              </h3>
              <button
                onClick={() => setShowSignalPanel(false)}
                className="text-[#9CA3AF] hover:text-[#111827]"
              >
                ✕
              </button>
            </div>

            <div className="flex flex-col gap-3">
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-semibold text-[#6B7280] uppercase tracking-wider">
                  Instrument
                </label>
                <div className="flex gap-2">
                  {INSTRUMENTS.map((ins) => (
                    <button
                      key={ins}
                      onClick={() => setSelectedInstrument(ins)}
                      className={`flex-1 py-2 rounded-lg text-sm font-semibold border transition-all ${
                        selectedInstrument === ins
                          ? "bg-[#111827] text-white border-[#111827]"
                          : "bg-white text-[#6B7280] border-[#E5E7EB] hover:border-[#111827]"
                      }`}
                    >
                      {ins}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-semibold text-[#6B7280] uppercase tracking-wider">
                  Timeframe
                </label>
                <div className="flex gap-2">
                  {TIMEFRAMES.map((tf) => (
                    <button
                      key={tf}
                      onClick={() => setSelectedTimeframe(tf)}
                      className={`flex-1 py-2 rounded-lg text-sm font-semibold border transition-all ${
                        selectedTimeframe === tf
                          ? "bg-[#2563EB] text-white border-[#2563EB]"
                          : "bg-white text-[#6B7280] border-[#E5E7EB] hover:border-[#2563EB]"
                      }`}
                    >
                      {tf}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="bg-[#F9FAFB] rounded-xl p-3 text-xs text-[#6B7280]">
              <p>
                ⚙️ <strong className="text-[#111827]">Risk:</strong> 0.3% equity
                per trade
              </p>
              <p>
                🛡️ <strong className="text-[#111827]">Regime:</strong> ADX ≥ 14 +
                ATR ≥ 30th pct
              </p>
              <p>
                ⏱️ <strong className="text-[#111827]">Kill:</strong> 18h
                time-decay
              </p>
            </div>

            {triggerSignal.isError && (
              <p className="text-xs text-[#EF4444]">
                {triggerSignal.error?.message || "Signal failed"}
              </p>
            )}
            {triggerSignal.data?.error && (
              <p className="text-xs text-[#EF4444]">
                {triggerSignal.data.error}
              </p>
            )}

            <ActionPill
              icon={RefreshCw}
              onClick={() =>
                triggerSignal.mutate({
                  instrument: selectedInstrument,
                  timeframe: selectedTimeframe,
                })
              }
              className="w-full justify-center"
            >
              {triggerSignal.isPending
                ? "Processing..."
                : `Run ${selectedInstrument} ${selectedTimeframe}`}
            </ActionPill>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex flex-col gap-1">
          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-semibold tracking-tight text-[#111827]">
              KRONOS + SHADOW AI
            </h1>
            <StatusPill
              status={systemState?.is_paused ? "BLOCKED" : "ACTIVE"}
              label={systemState?.is_paused ? "Paused" : "Operational"}
            />
          </div>
          <p className="text-[#6B7280] text-sm">
            FX Signal Engine v3.0 — Qwen-Plus · SMC · Prop Firm Hardened
          </p>
        </div>

        <div className="flex items-center gap-3">
          <ActionPill
            icon={systemState?.is_paused ? Play : Pause}
            onClick={() => togglePause.mutate(!systemState?.is_paused)}
          >
            {systemState?.is_paused ? "Resume" : "Pause"}
          </ActionPill>
          <ActionPill icon={RefreshCw} onClick={() => setShowSignalPanel(true)}>
            Trigger Signal
          </ActionPill>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {stats.map((s, i) => (
          <Card key={i} className="py-5">
            <div className="flex flex-col gap-1">
              <span className="text-xs font-medium text-[#6B7280] uppercase tracking-wider">
                {s.label}
              </span>
              <div className="flex items-baseline gap-2">
                <span className="text-2xl font-semibold text-[#111827]">
                  {s.value}
                </span>
                <span
                  className={`text-xs font-medium ${s.up ? "text-[#10B981]" : "text-[#EF4444]"}`}
                >
                  {s.trend}
                </span>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* Tabs */}
      <div className="flex border-b border-[#E5E7EB] w-full overflow-x-auto">
        {["overview", "signals", "audit-log", "risk"].map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-4 pb-3 text-sm transition-all capitalize whitespace-nowrap ${
              activeTab === tab
                ? "text-[#111827] font-semibold border-b-2 border-[#2563EB] -mb-[1px]"
                : "text-[#6B7280] font-normal border-b-2 border-transparent hover:text-[#111827]"
            }`}
          >
            {tab.replace("-", " ")}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <div className="min-h-[500px]">
        {/* OVERVIEW */}
        {activeTab === "overview" && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card
              title="P&L History"
              subtitle="Closed trade outcomes (pips)"
              className="lg:col-span-2 h-[400px]"
            >
              <div className="h-full w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={closedTrades.slice(-20).reverse()}>
                    <defs>
                      <linearGradient id="colorPnL" x1="0" y1="0" x2="0" y2="1">
                        <stop
                          offset="5%"
                          stopColor="#2563EB"
                          stopOpacity={0.1}
                        />
                        <stop
                          offset="95%"
                          stopColor="#2563EB"
                          stopOpacity={0}
                        />
                      </linearGradient>
                    </defs>
                    <CartesianGrid
                      strokeDasharray="3 3"
                      vertical={false}
                      stroke="#F3F4F6"
                    />
                    <XAxis dataKey="created_at" hide />
                    <YAxis hide domain={["auto", "auto"]} />
                    <Tooltip
                      contentStyle={{
                        borderRadius: "8px",
                        border: "1px solid #E5E7EB",
                        boxShadow: "none",
                      }}
                      itemStyle={{ color: "#111827", fontSize: "12px" }}
                    />
                    <Area
                      type="monotone"
                      dataKey="outcome_pnl_pips"
                      stroke="#2563EB"
                      fillOpacity={1}
                      fill="url(#colorPnL)"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </Card>

            <Card title="System Health" subtitle="Real-time regime metrics">
              <div className="flex flex-wrap gap-8 justify-around py-4">
                <CircularRing value={winRate} label="Win Rate" />
                <CircularRing
                  value={Math.min(100, maxDD * 5)}
                  label="Daily DD"
                  color="#EF4444"
                />
                <CircularRing
                  value={Math.max(0, 100 - winRate)}
                  label="Block Rate"
                  color="#10B981"
                />
              </div>
              <div className="flex flex-col gap-3 pt-4 border-t border-[#E5E7EB]">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-[#6B7280]">
                    ADX Min Threshold
                  </span>
                  <span className="text-sm font-semibold text-[#111827]">
                    14
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-[#6B7280]">Risk / Trade</span>
                  <span className="text-sm font-semibold text-[#111827]">
                    0.3%
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-[#6B7280]">
                    Max Consec. Losses
                  </span>
                  <span className="text-sm font-semibold text-[#111827]">
                    3
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-[#6B7280]">
                    Time Decay Kill
                  </span>
                  <span className="text-sm font-semibold text-[#111827]">
                    18h
                  </span>
                </div>
              </div>
            </Card>
          </div>
        )}

        {/* SIGNALS */}
        {activeTab === "signals" && (
          <div className="flex flex-col gap-4">
            {activeTrades.length === 0 && (
              <div className="flex flex-col items-center justify-center py-20 text-[#9CA3AF]">
                <Activity size={40} className="mb-3 opacity-30" />
                <p className="text-sm">No active signals. Trigger one above.</p>
              </div>
            )}
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
              {activeTrades.map((log) => (
                <Card
                  key={log.id}
                  className="hover:border-[#D1D5DB] transition-colors"
                >
                  <div className="flex justify-between items-start">
                    <div className="flex flex-col gap-1">
                      <div className="flex items-center gap-2">
                        <span className="text-lg font-semibold text-[#111827]">
                          {log.instrument}
                        </span>
                        <MetaPill>{log.timeframe}</MetaPill>
                      </div>
                      <div className="flex items-center gap-1.5">
                        {log.direction === "LONG" ? (
                          <TrendingUp size={14} className="text-[#10B981]" />
                        ) : (
                          <TrendingDown size={14} className="text-[#EF4444]" />
                        )}
                        <span
                          className={`text-sm font-bold ${log.direction === "LONG" ? "text-[#10B981]" : "text-[#EF4444]"}`}
                        >
                          {log.direction}
                        </span>
                      </div>
                    </div>
                    <StatusPill status={log.outcome} label={log.outcome} />
                  </div>

                  <div className="grid grid-cols-2 gap-4 py-4">
                    {[
                      {
                        label: "Entry",
                        value: log.entry_price,
                        color: "#111827",
                      },
                      { label: "Lot", value: log.lot_size, color: "#111827" },
                      {
                        label: "TP1",
                        value: log.take_profit_1,
                        color: "#10B981",
                      },
                      { label: "SL", value: log.stop_loss, color: "#EF4444" },
                      {
                        label: "TP2",
                        value: log.take_profit_2,
                        color: "#10B981",
                      },
                      {
                        label: "Risk",
                        value: `${log.risk_percent}%`,
                        color: "#6B7280",
                      },
                    ].map((f) => (
                      <div key={f.label} className="flex flex-col gap-0.5">
                        <span className="text-[10px] text-[#6B7280] uppercase tracking-wider font-semibold">
                          {f.label}
                        </span>
                        <span
                          className="text-sm font-medium"
                          style={{ color: f.color }}
                        >
                          {f.value}
                        </span>
                      </div>
                    ))}
                  </div>

                  <div className="flex items-center gap-2 pb-3 border-b border-[#E5E7EB]">
                    <Brain size={12} className="text-[#6B7280] shrink-0" />
                    <span className="text-[10px] text-[#6B7280] italic truncate">
                      {log.smc_context || "SMC analysis pending"}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 pt-3">
                    <Fingerprint size={14} className="text-[#6B7280]" />
                    <span className="text-[10px] text-[#6B7280] font-mono truncate">
                      {log.prompt_hash}
                    </span>
                    <div className="flex items-center gap-1 ml-auto">
                      <button
                        onClick={() =>
                          closeTrade.mutate({
                            id: log.id,
                            outcome: "tp2_hit",
                            pips: 120,
                          })
                        }
                        className="p-1 hover:bg-green-50 text-[#10B981] rounded"
                        title="Mark TP2 Hit"
                      >
                        <CheckCircle2 size={14} />
                      </button>
                      <button
                        onClick={() =>
                          closeTrade.mutate({
                            id: log.id,
                            outcome: "sl_hit",
                            pips: -60,
                          })
                        }
                        className="p-1 hover:bg-red-50 text-[#EF4444] rounded"
                        title="Mark SL Hit"
                      >
                        <XCircle size={14} />
                      </button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* AUDIT LOG */}
        {activeTab === "audit-log" && (
          <Card className="overflow-hidden p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead className="bg-[#F9FAFB] border-b border-[#E5E7EB]">
                  <tr>
                    {[
                      "Timestamp",
                      "Instrument",
                      "Status",
                      "ADX / Unc",
                      "Direction",
                      "Outcome",
                      "P&L (p)",
                    ].map((h) => (
                      <th
                        key={h}
                        className="px-5 py-4 text-xs font-semibold text-[#6B7280] uppercase tracking-wider whitespace-nowrap"
                      >
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E5E7EB]">
                  {logs.map((log) => (
                    <tr
                      key={log.id}
                      className="hover:bg-[#F9FAFB] transition-colors"
                    >
                      <td className="px-5 py-4 text-sm text-[#6B7280] whitespace-nowrap">
                        {format(new Date(log.created_at), "MMM dd, HH:mm")}
                      </td>
                      <td className="px-5 py-4">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-semibold text-[#111827]">
                            {log.instrument}
                          </span>
                          <span className="text-[10px] font-medium text-[#6B7280] px-1.5 py-0.5 rounded border border-[#E5E7EB]">
                            {log.timeframe}
                          </span>
                        </div>
                      </td>
                      <td className="px-5 py-4">
                        <StatusPill
                          status={log.signal_status}
                          label={log.signal_status}
                        />
                      </td>
                      <td className="px-5 py-4">
                        <div className="flex items-center gap-3">
                          <div className="flex flex-col">
                            <span className="text-[10px] text-[#6B7280] uppercase font-bold">
                              ADX
                            </span>
                            <span
                              className={`text-xs font-medium ${log.adx_value >= 14 ? "text-[#10B981]" : "text-[#EF4444]"}`}
                            >
                              {log.adx_value?.toFixed(1)}
                            </span>
                          </div>
                          <div className="flex flex-col">
                            <span className="text-[10px] text-[#6B7280] uppercase font-bold">
                              UNC
                            </span>
                            <span
                              className={`text-xs font-medium ${log.uncertainty_score <= 0.65 ? "text-[#10B981]" : "text-[#EF4444]"}`}
                            >
                              {log.uncertainty_score?.toFixed(2)}
                            </span>
                          </div>
                        </div>
                      </td>
                      <td className="px-5 py-4">
                        {log.direction ? (
                          <div className="flex items-center gap-1">
                            {log.direction === "LONG" ? (
                              <TrendingUp
                                size={12}
                                className="text-[#10B981]"
                              />
                            ) : (
                              <TrendingDown
                                size={12}
                                className="text-[#EF4444]"
                              />
                            )}
                            <span
                              className={`text-xs font-semibold ${log.direction === "LONG" ? "text-[#10B981]" : "text-[#EF4444]"}`}
                            >
                              {log.direction}
                            </span>
                          </div>
                        ) : (
                          <span className="text-xs text-[#D1D5DB]">—</span>
                        )}
                      </td>
                      <td className="px-5 py-4">
                        <span
                          className={`text-xs font-medium capitalize ${
                            log.outcome === "tp2_hit" ||
                            log.outcome === "tp1_hit"
                              ? "text-[#10B981]"
                              : log.outcome === "sl_hit"
                                ? "text-[#EF4444]"
                                : "text-[#6B7280]"
                          }`}
                        >
                          {log.outcome}
                        </span>
                      </td>
                      <td className="px-5 py-4 text-right">
                        <span
                          className={`text-sm font-semibold ${
                            log.outcome_pnl_pips > 0
                              ? "text-[#10B981]"
                              : log.outcome_pnl_pips < 0
                                ? "text-[#EF4444]"
                                : "text-[#111827]"
                          }`}
                        >
                          {log.outcome_pnl_pips != null
                            ? `${log.outcome_pnl_pips > 0 ? "+" : ""}${log.outcome_pnl_pips}`
                            : "—"}
                        </span>
                      </td>
                    </tr>
                  ))}
                  {logs.length === 0 && (
                    <tr>
                      <td
                        colSpan={7}
                        className="px-5 py-12 text-center text-sm text-[#9CA3AF]"
                      >
                        No audit records yet. Trigger a signal to begin.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </Card>
        )}

        {/* RISK */}
        {activeTab === "risk" && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card
              title="Risk Architecture"
              subtitle="ShadowAlgo v3.0 — Alpha Rehabilitation"
            >
              <div className="flex flex-col gap-4">
                {[
                  { label: "Risk / Trade", value: "0.3% equity", ok: true },
                  { label: "SL Placement", value: "1.5 × ATR(14)", ok: true },
                  {
                    label: "ADX Regime Gate",
                    value: "≥ 14 (Hard Block)",
                    ok: true,
                  },
                  {
                    label: "ATR Percentile Gate",
                    value: "≥ 30th pct",
                    ok: true,
                  },
                  { label: "Uncertainty Block", value: "> 0.65", ok: true },
                  {
                    label: "Breakeven Buffer",
                    value: "+1.5 pips after 1:1 RR",
                    ok: true,
                  },
                  {
                    label: "Partial TP",
                    value: "50% close at 1:2 RR",
                    ok: true,
                  },
                  { label: "Time-Decay Kill", value: "18h max hold", ok: true },
                  {
                    label: "Consec. Loss Kill",
                    value: "3 losses → halt",
                    ok: true,
                  },
                  {
                    label: "Daily Loss Halt",
                    value: "4.5% daily DD",
                    ok: true,
                  },
                  {
                    label: "Weekly Loss Halt",
                    value: "8% weekly DD",
                    ok: true,
                  },
                  {
                    label: "Supported Assets",
                    value: "EURUSD, XAUUSD",
                    ok: true,
                  },
                ].map((r) => (
                  <div
                    key={r.label}
                    className="flex items-center justify-between"
                  >
                    <span className="text-sm text-[#6B7280]">{r.label}</span>
                    <div className="flex items-center gap-1.5">
                      <span className="text-sm font-semibold text-[#111827]">
                        {r.value}
                      </span>
                      <CheckCircle2 size={12} className="text-[#10B981]" />
                    </div>
                  </div>
                ))}
              </div>
            </Card>

            <Card
              title="Few-Shot Failure Signatures"
              subtitle="Patch 3 — Autopsy Injection (loss rate → block)"
            >
              <div className="flex flex-col gap-3">
                {FAILURE_PATTERNS.map((p) => (
                  <div
                    key={p.id}
                    className="flex flex-col gap-1 p-3 rounded-xl bg-[#F9FAFB] border border-[#E5E7EB]"
                  >
                    <div className="flex items-center justify-between">
                      <span
                        className="text-xs font-bold font-mono"
                        style={{ color: p.color }}
                      >
                        {p.name}
                      </span>
                      <span
                        className="text-xs font-bold"
                        style={{ color: p.color }}
                      >
                        Loss: {p.risk}
                      </span>
                    </div>
                    <p className="text-[11px] text-[#6B7280]">
                      {p.desc} — <em>DO NOT TRADE</em>
                    </p>
                  </div>
                ))}
                <p className="text-[10px] text-[#9CA3AF] pt-2">
                  These patterns are injected as few-shot context into every
                  Qwen-Plus LLM call.
                </p>
              </div>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
